/* Aureum Tipoff: offline educational research studio. No live NBA feeds. */
(()=>{'use strict';
const el=id=>document.getElementById(id);
const teamList=Array.isArray(window.teams)?window.teams:teams;
const teamName=code=>teamList.find(t=>t[0]===code)?.[1]||code;
const fieldIds=['studioAway','studioHome','studioAwayStrength','studioHomeStrength','studioAwayRest','studioHomeRest','studioAwayAbsence','studioHomeAbsence','studioHomeCourt'];
const defaultState={studioAway:'GSW',studioHome:'BOS',studioAwayStrength:'70',studioHomeStrength:'70',studioAwayRest:'1',studioHomeRest:'1',studioAwayAbsence:'0',studioHomeAbsence:'0',studioHomeCourt:'3'};
const storeKey='aureum-tipoff-scenarios-v2';
const options=teamList.map(t=>`<option value="${t[0]}">${t[1]}</option>`).join('');
['studioAway','studioHome'].forEach(id=>el(id).innerHTML=options);
function apply(s){for(const id of fieldIds){if(s[id]!==undefined)el(id).value=s[id]}draw()}
function read(){return Object.fromEntries(fieldIds.map(id=>[id,el(id).value]))}
function estimate(s){
 const strength=Number(s.studioAwayStrength)-Number(s.studioHomeStrength);
 const rest=(Math.min(3,Number(s.studioAwayRest))-Math.min(3,Number(s.studioHomeRest)))*1.5;
 const availability=(Number(s.studioHomeAbsence)-Number(s.studioAwayAbsence))*5;
 const home=-Number(s.studioHomeCourt);
 const total=strength+rest+availability+home;
 const away=100/(1+Math.exp(-total/16));
 return {strength,rest,availability,home,total,away,homePct:100-away};
}
function draw(){const s=read(),r=estimate(s),valid=s.studioAway!==s.studioHome;
 el('studioAwayStrengthValue').textContent=s.studioAwayStrength;el('studioHomeStrengthValue').textContent=s.studioHomeStrength;el('studioHomeCourtValue').textContent=s.studioHomeCourt;
 el('studioAwayName').textContent=teamName(s.studioAway);el('studioHomeName').textContent=teamName(s.studioHome);
 el('studioAwayPct').textContent=valid?Math.round(r.away)+'%':'—';el('studioHomePct').textContent=valid?100-Math.round(r.away)+'%':'—';el('studioBar').style.width=valid?r.away+'%':'50%';
 el('studioHeadline').textContent=!valid?'Select two different teams':Math.abs(r.away-50)<7?'An evenly balanced hypothetical':`${teamName(r.away>50?s.studioAway:s.studioHome)} has the illustrative advantage`;
 el('studioExplanation').textContent=!valid?'A team cannot play itself. Change one selection to continue.':`With the assumptions you selected, ${teamName(s.studioAway)} receives ${Math.round(r.away)}% and ${teamName(s.studioHome)} receives ${100-Math.round(r.away)}%. These are hypothetical percentages—not a prediction for a scheduled game.`;
 const factors=[['Team-strength gap',r.strength,'Difference between your two manual 0–100 team-strength settings.'],['Rest difference',r.rest,'Illustrative 1.5-point effect per extra rest day, capped at three days.'],['Player availability',r.availability,'Illustrative 5-point effect per availability level; no actual injury reports are used.'],['Home-court setting',r.home,'Your selected advantage for the home team.']];
 el('studioFactors').replaceChildren(...factors.map(([label,value,description])=>{const node=document.createElement('div');node.className='factor';const left=document.createElement('div');const strong=document.createElement('strong');strong.textContent=label;const p=document.createElement('p');p.textContent=description;left.append(strong,p);const val=document.createElement('b');val.textContent=(value>0?'+':'')+value.toFixed(1);node.append(left,val);return node}));
 return {s,r,valid};
}
fieldIds.forEach(id=>el(id).addEventListener('input',draw));
function saved(){try{const a=JSON.parse(localStorage.getItem(storeKey)||'[]');return Array.isArray(a)?a.slice(0,12):[]}catch{return []}}
function persist(a){try{localStorage.setItem(storeKey,JSON.stringify(a));return true}catch{el('studioStatus').textContent='Browser storage is unavailable. The scenario remains usable without saving.';return false}}
function renderSaved(){const list=saved(),root=el('studioSaved');root.replaceChildren();if(!list.length){const empty=document.createElement('p');empty.className='notice';empty.textContent='No saved scenarios yet. Configure a matchup above and choose Save scenario locally.';root.append(empty);return}list.forEach((item,index)=>{const card=document.createElement('div');card.className='saved-entry';const h=document.createElement('h4');h.textContent=`${item.s.studioAway} vs ${item.s.studioHome}`;const p=document.createElement('p');p.textContent=`${Math.round(estimate(item.s).away)}% illustrative away share · ${new Date(item.date).toLocaleDateString()}`;const btn=document.createElement('button');btn.textContent='Load scenario';btn.addEventListener('click',()=>{apply(item.s);el('studioStatus').textContent='Saved scenario loaded.';window.scrollTo({top:0,behavior:'smooth'})});card.append(h,p,btn);root.append(card)})}
el('studioSave').addEventListener('click',()=>{const {s,valid}=draw();if(!valid){el('studioStatus').textContent='Choose two different teams before saving.';return}if(persist([{s,date:new Date().toISOString()},...saved()].slice(0,12))){el('studioStatus').textContent='Scenario saved in this browser.';renderSaved()}});
el('studioReset').addEventListener('click',()=>{apply(defaultState);el('studioStatus').textContent='Scenario reset to neutral assumptions.'});
el('studioClear').addEventListener('click',()=>{persist([]);renderSaved();el('studioStatus').textContent='Saved scenarios cleared.'});
el('studioShare').addEventListener('click',async()=>{const {s,r,valid}=draw();if(!valid){el('studioStatus').textContent='Choose two different teams first.';return}const summary=`Aureum Tipoff | Educational scenario (not an NBA forecast)\n${teamName(s.studioAway)} away vs ${teamName(s.studioHome)} home\nIllustrative shares: ${Math.round(r.away)}% / ${100-Math.round(r.away)}%\nManual strengths: ${s.studioAwayStrength} / ${s.studioHomeStrength}; rest days: ${s.studioAwayRest} / ${s.studioHomeRest}; hypothetical availability levels: ${s.studioAwayAbsence} / ${s.studioHomeAbsence}; home setting: ${s.studioHomeCourt}.\nNo live or verified NBA data is used.`;try{await navigator.clipboard.writeText(summary);el('studioStatus').textContent='Scenario summary copied.'}catch{el('studioStatus').textContent='Clipboard unavailable in this browser. Use a secure local or HTTPS context.'}});
const glossary=[
 ['Offensive rating','Points scored per 100 possessions.','100 × points scored / estimated possessions','Shows scoring efficiency independent of game speed.','Small samples and opponent quality can distort it.'],
 ['Defensive rating','Points allowed per 100 possessions.','100 × points allowed / estimated possessions','Lower is better: it measures how efficiently a team prevents scoring.','Not a pure measure of individual defense.'],
 ['Net rating','Offensive rating minus defensive rating.','Offensive rating − defensive rating','A positive number means a team scores more than it allows per 100 possessions.','Can be inflated by weak opponents or small samples.'],
 ['Pace','Estimated possessions played per 48 minutes.','Estimated possessions × 48 / minutes played','Distinguishes fast teams from slow, deliberate teams.','Pace alone does not indicate quality.'],
 ['Effective field-goal percentage (eFG%)','A shooting measure that gives extra credit for three-pointers.','(FGM + 0.5 × 3PM) / FGA','Accounts for a made three being worth more than a made two.','Excludes free throws.'],
 ['True shooting percentage (TS%)','Scoring efficiency that includes two-pointers, three-pointers and free throws.','Points / [2 × (FGA + 0.44 × FTA)]','Useful for comparing scoring efficiency across shot types.','The 0.44 free-throw adjustment is an approximation.'],
 ['Turnover rate','How often a possession ends with a turnover.','Turnovers / estimated possessions','A lower rate generally means fewer wasted possessions.','Definitions vary by data provider.'],
 ['Offensive rebound percentage','Share of available offensive rebounds a team collects.','Offensive rebounds / (offensive rebounds + opponent defensive rebounds)','Shows how often a team extends a possession after a miss.','Can reflect team strategy, not just rebounding talent.'],
 ['Usage rate','Estimate of a player’s share of team possessions used while on court.','Uses FGA, FTA, turnovers and playing time','Shows offensive involvement, not necessarily effectiveness.','High usage does not automatically mean high impact.'],
 ['Brier score','Average squared error between a probability and an actual result.','Mean[(predicted probability − result)²]','Lower is better; rewards accurate, well-calibrated probabilities.','Compare against a simple baseline, not just another complex model.'],
 ['Calibration','Whether predicted probabilities match long-run frequencies.','Compare predicted bins with observed win rates','A well-calibrated 70% forecast should succeed about 70% of the time across many games.','Requires a large, genuinely out-of-sample set.'],
 ['Home-court advantage','The tendency for home teams to perform differently from away teams.','Estimated from historical outcomes with controls','Can improve pregame models when fitted on real data.','The size changes by era, teams and context.']
];
function glossaryRender(){const q=el('glossarySearch').value.toLowerCase().trim(),items=glossary.filter(x=>x.join(' ').toLowerCase().includes(q));const root=el('glossaryGrid');root.replaceChildren();if(!items.length){const p=document.createElement('p');p.className='notice';p.textContent='No matching metrics. Try a broader basketball term.';root.append(p);return}for(const [title,definition,formula,meaning,caution] of items){const article=document.createElement('article');article.className='glossary-entry';const h=document.createElement('h3');h.textContent=title;const p=document.createElement('p');p.textContent=definition;const f=document.createElement('div');f.className='formula';f.textContent='How it works: '+formula;const why=document.createElement('p');why.textContent='Why it matters: '+meaning;const caveat=document.createElement('div');caveat.className='caution';caveat.textContent='Watch out: '+caution;article.append(h,p,f,why,caveat);root.append(article)}}
el('glossarySearch').addEventListener('input',glossaryRender);
apply(defaultState);renderSaved();glossaryRender();
})();
