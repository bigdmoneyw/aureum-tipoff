/* Aureum Tipoff — private, browser-local file research. No uploads, no credentials, no live claims. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const registered = new Map((Array.isArray(window.teams) ? window.teams : teams).map(t => [t[0],t[1]]));
  const known = [...registered.keys()].sort();
  const normalize = text => String(text||'').trim().toLowerCase().replace(/[\s-]+/g,'_');
  const aliases = new Map();
  for(const [code,name] of registered) {aliases.set(code.toLowerCase(),code);aliases.set(name.toLowerCase(),code);}
  [['la clippers','LAC'],['l.a. clippers','LAC']].forEach(([a,b])=>aliases.set(a,b));
  const officialTeamIds={"1610612737":"ATL","1610612738":"BOS","1610612751":"BKN","1610612766":"CHA","1610612741":"CHI","1610612739":"CLE","1610612742":"DAL","1610612743":"DEN","1610612765":"DET","1610612744":"GSW","1610612745":"HOU","1610612754":"IND","1610612746":"LAC","1610612747":"LAL","1610612763":"MEM","1610612748":"MIA","1610612749":"MIL","1610612750":"MIN","1610612740":"NOP","1610612752":"NYK","1610612760":"OKC","1610612753":"ORL","1610612755":"PHI","1610612756":"PHX","1610612757":"POR","1610612758":"SAC","1610612759":"SAS","1610612761":"TOR","1610612762":"UTA","1610612764":"WAS"};
  for (const [id,code] of Object.entries(officialTeamIds)) aliases.set(id,code);

  const e = text => String(text??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const nyCalendar = () => {const fmt=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'numeric'}).formatToParts(new Date());return {year:Number(fmt.find(x=>x.type==='year').value),month:Number(fmt.find(x=>x.type==='month').value)};};
  const years = () => {const now=nyCalendar();return Math.max(2026,now.month>=10?now.year:now.year-1);};
  const completedSeason = year => year < years() || (year === years() && nyCalendar().month >= 7 && nyCalendar().month <= 9);
  const seasonLabel = year => `${year}-${String((year+1)%100).padStart(2,'0')}`;
  const expectedFiles = () => Array.from({length:years()-2024+1},(_,i)=>`${seasonLabel(2024+i)}-team-game-results.csv`);
  const fixed = (n,d=4) => Number.isFinite(n)?Math.round(n*10**d)/10**d:null;
  const mean = arr => arr.length?arr.reduce((a,b)=>a+b,0)/arr.length:null;
  function csvParse(text) {
    if(typeof text!=='string'||!text.trim()||text.length>6000000) throw Error('A CSV is empty or exceeds the 6 MB safety limit.');
    text=text.replace(/^\uFEFF/,'');
    const lines=[],row=[];let cell='',quoted=false,fieldStart=true;
    for(let i=0;i<text.length;i++) {
      const ch=text[i];
      if(quoted){if(ch==='"'&&text[i+1]==='"'){cell+='"';i++;}else if(ch==='"')quoted=false;else cell+=ch;}
      else if(ch==='"') {if(!fieldStart)throw Error('Invalid CSV quoting.');quoted=true;fieldStart=false;}
      else if(ch===','){row.push(cell);cell='';fieldStart=true;}
      else if(ch==='\r'||ch==='\n'){row.push(cell);if(row.some(x=>x.trim()))lines.push(row.slice());row.length=0;cell='';fieldStart=true;if(ch==='\r'&&text[i+1]==='\n')i++;}
      else {cell+=ch;fieldStart=false;}
    }
    if(quoted)throw Error('Unclosed quote in CSV.');
    if(row.length||cell){row.push(cell);if(row.some(x=>x.trim()))lines.push(row);}
    if(lines.length<2||lines.length>8000)throw Error('CSV must contain a header and at most 8,000 records.');
    const headers=lines.shift().map(normalize);
    if(headers.some((h,i)=>!h||headers.indexOf(h)!==i))throw Error('CSV headers are empty or duplicated.');
    return {headers,rows:lines.map((line,i)=>{
      if(line.length!==headers.length)throw Error(`CSV row ${i+2} has ${line.length} columns; expected ${headers.length}.`);
      return Object.fromEntries(headers.map((h,n)=>[h,line[n].trim()]));
    })};
  }
  function pick(row,...keys){for(const key of keys){if(row[key]!==undefined&&row[key]!=='')return row[key];}return null;}
  function homeFlag(value){const s=String(value||'').toLowerCase().trim();if(['1','true','t','home','h','yes','vs','vs.'].includes(s))return true;if(['0','false','f','away','a','no','@'].includes(s))return false;throw Error('A record lacks a valid home/away flag.');}
  function dateValue(value,year){const match=/^(\d{4})-?(\d{2})-?(\d{2})$/.exec(String(value||''));if(!match)throw Error('Game date must be an exact YYYY-MM-DD or YYYYMMDD calendar date; timestamps and trailing text are not accepted.');const iso=`${match[1]}-${match[2]}-${match[3]}`;const parsed=new Date(iso+'T12:00:00Z');if(Number.isNaN(+parsed)||parsed.toISOString().slice(0,10)!==iso)throw Error(`Invalid calendar date ${iso}.`);if(iso<`${year}-10-01`||iso>=`${year+1}-07-01`)throw Error(`Game ${iso} is outside ${seasonLabel(year)}.`);if(iso>new Date().toISOString().slice(0,10))throw Error('Future game results cannot be treated as completed.');return iso;}
  function parseGames(csv,year){
    const {headers,rows}=csvParse(csv);
    const select=(...options)=>options.find(x=>headers.includes(x));
    const idKey=select('game_id','gameid','nba_game_id','game'),dateKey=select('game_date','gamedate','date'),teamKey=select('team_abbreviation','team_abbr','team_code','team','team_id','team_name'),homeKey=select('is_home','home','home_away','location','venue'),scoreKey=select('points','pts','team_points','team_pts','team_score','score');
    if(!idKey||!dateKey||!teamKey||!homeKey||!scoreKey)throw Error(`CSV header mismatch for ${seasonLabel(year)}. Found: ${headers.join(', ')}. Expected game ID, date, team, home/away and points. No values were guessed.`);
    const byGame=new Map(),perDay=new Set();
    for(const [i,row] of rows.entries()){
      const id=row[idKey];if(!id||id.length>90)throw Error(`Invalid game identifier on row ${i+2}.`);
      const season=pick(row,'season','season_label','season_year');if(season&&!new Set([String(year),seasonLabel(year),`${year}-${year+1}`,`${year}/${String((year+1)%100).padStart(2,'0')}`]).has(season))throw Error(`Contradictory season label at row ${i+2}.`);
      const team=aliases.get(row[teamKey]?.toLowerCase());if(!team)throw Error(`Unknown NBA franchise in row ${i+2}: ${String(row[teamKey]).slice(0,60)}.`);
      const date=dateValue(row[dateKey],year),home=homeFlag(row[homeKey]);
      const score=Number(row[scoreKey]);if(!/^\d{1,3}(?:\.0+)?$/.test(row[scoreKey])||!Number.isInteger(score)||score<0||score>=300)throw Error(`Invalid points in row ${i+2}.`);
      const opponent=pick(row,'opponent_abbreviation','opponent_abbr','opponent_team','opponent','opp_team'),opp=opponent?aliases.get(opponent.toLowerCase()):null;
      if(opponent&&!opp)throw Error(`Invalid opponent on row ${i+2}.`);
      const oppPoints=pick(row,'opponent_points','opp_pts','opponent_score','opp_score');
      const entry={id,date,team,home,score,opp,oppPoints:oppPoints!==null?Number(oppPoints):null};
      if(oppPoints!==null&&(!Number.isInteger(entry.oppPoints)||entry.oppPoints<0||entry.oppPoints>=300))throw Error(`Invalid opponent score in row ${i+2}.`);
      if(!byGame.has(id))byGame.set(id,[]);byGame.get(id).push(entry);
    }
    const games=[];const teamsPlayed=Object.fromEntries(known.map(c=>[c,0]));
    for(const [id,pair] of byGame){
      if(pair.length!==2||pair[0].home===pair[1].home)throw Error(`Game ${id} must include exactly one home and one away team record.`);
      const h=pair.find(p=>p.home),a=pair.find(p=>!p.home);
      if(h.team===a.team||h.date!==a.date||h.score===a.score||h.opp&&h.opp!==a.team||a.opp&&a.opp!==h.team||h.oppPoints!==null&&h.oppPoints!==a.score||a.oppPoints!==null&&a.oppPoints!==h.score)throw Error(`Conflicting game rows in ${id}.`);
      for(const team of [h.team,a.team]){const key=`${h.date}|${team}`;if(perDay.has(key))throw Error(`${team} appears more than once on ${h.date}.`);perDay.add(key);teamsPlayed[team]++;}
      games.push({id:`bsl:${year}:${id}`,date:h.date,home:h.team,away:a.team,hs:h.score,as:a.score,season:year});
    }
    if(completedSeason(year)&&(games.length!==1230||known.some(c=>teamsPlayed[c]!==82)))throw Error(`${seasonLabel(year)} has ${games.length}/1,230 games; a complete season must have 82 games for every team. Historical accuracy cannot be computed.`);
    if(year===years()&&!games.length)throw Error('The latest season file has no completed games.');
    return games.sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
  }
  function predict(home,away,rating,settings){const difference=(rating[home]??1500)+settings.home_advantage-(rating[away]??1500);return 1/(1+10**(-difference/settings.logistic_scale));}
  function replay(games,settings){
    const rating={},last={},results=[];const sorted=[...games].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
    let start=0;
    while(start<sorted.length){let end=start+1;while(end<sorted.length&&sorted[end].date===sorted[start].date)end++;
      const change={},batch=[];
      for(const g of sorted.slice(start,end)){
        const p=predict(g.home,g.away,rating,settings),y=Number(g.hs>g.as);
        if(last[g.home]&&last[g.away])results.push({date:g.date,id:g.id,home_probability:p,actual_home_win:y,correct:Number(Number(p>=.5)===y)});
        const delta=settings.k*(y-p);change[g.home]=(change[g.home]||0)+delta;change[g.away]=(change[g.away]||0)-delta;batch.push(g);
      }
      for(const [code,delta] of Object.entries(change))rating[code]=(rating[code]??1500)+delta;
      for(const g of batch){last[g.home]=g.date;last[g.away]=g.date;}
      start=end;
    }
    return {rating,last,results};
  }
  function metrics(rows){if(!rows.length)return {games:0,accuracy:null,brier:null,log_loss:null};return {games:rows.length,accuracy:fixed(mean(rows.map(r=>r.correct))),brier:fixed(mean(rows.map(r=>(r.home_probability-r.actual_home_win)**2))),log_loss:fixed(mean(rows.map(r=>-r.actual_home_win*Math.log(Math.max(1e-12,r.home_probability))-(1-r.actual_home_win)*Math.log(Math.max(1e-12,1-r.home_probability)))))};}
  function calibration(rows){return Array.from({length:5},(_,i)=>{const group=rows.filter(r=>Math.min(4,Math.floor(r.home_probability*5))===i);return {label:`${20*i}–${20*(i+1)}%`,games:group.length,mean_prediction:fixed(mean(group.map(x=>x.home_probability))),observed_home_win:fixed(mean(group.map(x=>x.actual_home_win)))};});}
  function uncertainty(rows,constant){
    const weeks=new Map();for(const r of rows){const d=new Date(r.date+'T12:00:00Z'),w=new Date(+d-d.getUTCDay()*86400000).toISOString().slice(0,10);if(!weeks.has(w))weeks.set(w,[]);weeks.get(w).push(r);}
    const groups=[...weeks.values()],values=[],acc=[];let seed=20261114;
    const rand=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
    for(let sample=0;sample<350;sample++){
      let total=0,diff=0,hit=0;
      for(let i=0;i<groups.length;i++)for(const r of groups[Math.floor(rand()*groups.length)]){const y=r.actual_home_win;diff+=(constant-y)**2-(r.home_probability-y)**2;hit+=r.correct;total++;}
      if(total){values.push(diff/total);acc.push(hit/total);}
    }
    const interval=a=>{a.sort((x,y)=>x-y);return [fixed(a[Math.floor((a.length-1)*.025)]),fixed(a[Math.floor((a.length-1)*.975)])];};
    return {games:rows.length,brier_improvement:fixed(mean(rows.map(r=>(constant-r.actual_home_win)**2-(r.home_probability-r.actual_home_win)**2))),brier_improvement_95pct_interval:interval(values),winner_accuracy_95pct_interval:interval(acc),resampling_unit:'week-block resampling of basketball dates'};
  }
  function seasonPulse(games,year){
    const by=Object.fromEntries(known.map(c=>[c,{wins:0,losses:0,scored:0,allowed:0,recent:[]}]));
    for(const g of games)for(const [code,scored,allowed,opponent,place] of [[g.home,g.hs,g.as,g.away,'home'],[g.away,g.as,g.hs,g.home,'away']]){
      const t=by[code],result=scored>allowed?'W':'L';t[result==='W'?'wins':'losses']++;t.scored+=scored;t.allowed+=allowed;t.recent.push({id:g.id,date:g.date,opponent,place,scored,allowed,result});
    }
    const result={};for(const [code,t] of Object.entries(by)){
      const n=t.wins+t.losses,last=t.recent.at(-1)||null,streak=last?Array.from(t.recent).reverse().findIndex(x=>x.result!==last.result):-1;
      result[code]={wins:t.wins,losses:t.losses,win_pct:n?fixed(t.wins/n):null,ppg:n?fixed(t.scored/n,1):null,opp_ppg:n?fixed(t.allowed/n,1):null,point_diff:n?fixed((t.scored-t.allowed)/n,1):null,last_five:t.recent.slice(-5).map(x=>x.result).join(''),streak:last?last.result+(streak===-1?t.recent.length:streak):'—',last_game:last};
    }
    return {season:seasonLabel(year),games:games.length,teams:result,recent_games:games.slice(-12).reverse().map(g=>({id:g.id,date:g.date+'T12:00:00Z',home:g.home,away:g.away,home_score:g.hs,away_score:g.as})),scope:'Regular-season completed game results; browser-imported research only. Not official standings or live forecasts.'};
  }
  function sha256Fallback(input) {
    // Local SHA-256 for file:// previews and isolated browser test contexts
    // where Web Crypto is unavailable. Output is an exact-byte checksum.
    const bytes=new Uint8Array(input),size=((bytes.length+9+63)>>6)<<6;
    const data=new Uint8Array(size);data.set(bytes);data[bytes.length]=0x80;
    const bits=bytes.length*8;
    for(let i=0;i<8;i++)data[size-1-i]=Math.floor(bits/2**(8*i))&255;
    const primes=[];
    for(let n=2;primes.length<64;n++){
      let prime=true;for(let k=2;k*k<=n;k++)if(n%k===0){prime=false;break;}
      if(prime)primes.push(n);
    }
    const fract=n=>Math.floor((n-Math.floor(n))*4294967296)>>>0;
    const constants=primes.map(p=>fract(Math.cbrt(p)));
    const h=primes.slice(0,8).map(p=>fract(Math.sqrt(p)));
    const rotate=(n,r)=>(n>>>r)|(n<<(32-r));
    const words=new Uint32Array(64);
    for(let pos=0;pos<size;pos+=64){
      for(let i=0;i<16;i++){
        const j=pos+4*i;
        words[i]=((data[j]<<24)|(data[j+1]<<16)|(data[j+2]<<8)|data[j+3])>>>0;
      }
      for(let i=16;i<64;i++){
        const a=words[i-15],b=words[i-2];
        const s0=rotate(a,7)^rotate(a,18)^(a>>>3);
        const s1=rotate(b,17)^rotate(b,19)^(b>>>10);
        words[i]=(words[i-16]+s0+words[i-7]+s1)>>>0;
      }
      let [a,b,c,d,e,f,g,z]=h;
      for(let i=0;i<64;i++){
        const s1=rotate(e,6)^rotate(e,11)^rotate(e,25);
        const choice=(e&f)^(~e&g);
        const t1=(z+s1+choice+constants[i]+words[i])>>>0;
        const s0=rotate(a,2)^rotate(a,13)^rotate(a,22);
        const maj=(a&b)^(a&c)^(b&c);
        const t2=(s0+maj)>>>0;
        z=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
      }
      for(const [i,v] of [a,b,c,d,e,f,g,z].entries())h[i]=(h[i]+v)>>>0;
    }
    return h.map(n=>n.toString(16).padStart(8,'0')).join('');
  }
  async function fileEvidence(file) {
    // Fingerprints help reproduce an audit, but cannot verify publisher identity.
    const content=await file.arrayBuffer();
    let sha256;
    if(window.crypto?.subtle){
      const digest=await window.crypto.subtle.digest('SHA-256',content);
      sha256=[...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,'0')).join('');
    }else sha256=sha256Fallback(content);
    let text;
    try {text=new TextDecoder('utf-8',{fatal:true}).decode(content);}
    catch {throw Error(`${file.name} is not valid UTF-8 text.`);}
    return {text,bytes:content.byteLength,sha256};
  }
  function buildSnapshot(gamesByYear){
    const train=gamesByYear.get(2024),holdout=gamesByYear.get(2025),all=[...gamesByYear.values()].flat().sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
    let best=null;for(const k of [10,20,30])for(const home_advantage of [35,65,95])for(const logistic_scale of [300,400]){
      const settings={k,home_advantage,logistic_scale,starting_rating:1500};const result=replay(train,settings).results;
      const error=mean(result.map(r=>(r.home_probability-r.actual_home_win)**2));if(error!==null&&(!best||error<best.error))best={settings,error};
    }
    if(!best)throw Error('Not enough training games to select a model.');
    const overall=replay(all,best.settings),hold=overall.results.filter(r=>r.date>='2025-10-01'&&r.date<'2026-07-01');
    if(hold.length<1100)throw Error(`Only ${hold.length} holdout games could be scored; historical evaluation was rejected.`);
    const pHome=mean(train.map(g=>Number(g.hs>g.as))),baseline=hold.map(r=>({...r,home_probability:.5,correct:Number(r.actual_home_win===1)})),learned=hold.map(r=>({...r,home_probability:pHome,correct:Number(Number(pHome>=.5)===r.actual_home_win)}));
    const m=metrics(hold),b=metrics(learned),current=years(),currentGames=gamesByYear.get(current),pulse=seasonPulse(currentGames,current),last=all.at(-1);
    const now=new Date().toISOString(),source='User-supplied, unauthenticated CSV files claimed in BoxScore Lab format · attribution if authentic: BoxScore Lab, CC BY 4.0 · https://boxscorelab.com/downloads/';
    return {schema_version:2,generated_at:now,source_checked_at:now,data_through:last.date+'T12:00:00Z',source,season:seasonLabel(current),
      model:{id:'elo_local_browser_research',settings:best.settings,training:{status:'trained_2024_25',training_games:train.length,candidate_count:18,training_brier:fixed(best.error)}},
      teams:Object.fromEntries(known.map(code=>[code,{rating:fixed(overall.rating[code]??1500,0),historical_wins:0,historical_losses:0,last_played:overall.last[code]||null}])),
      forecasts:[],injuries:null,injury_source_status:'unavailable',injury_retrieved_at:null,
      validation:{train_2024_25:{status:'trained_2024_25',training_games:train.length},holdout_2025_26:m,holdout_uncertainty_2025_26:uncertainty(hold,pHome),baseline_2025_26:metrics(baseline),training_home_rate:fixed(pHome),learned_home_baseline_2025_26:b,brier_skill_vs_learned_baseline:b.brier?fixed(1-m.brier/b.brier):null,holdout_calibration:calibration(hold),method:'Local browser import: training settings selected from 18 Elo candidates using 2024–25 only; fixed 2025–26 holdout. Retrospective same-date game batching; no injuries or schedule forecasts.',note:'Results are historical replay, not prospectively timestamped predictions.'},
      prospective_validation:metrics([]),forecast_archive_count:0,forecasts_archived:[],
      season_pulse:pulse, data_coverage:{adapter:'local_browser_manual_import',dates_cached:new Set(all.map(g=>g.date)).size,failure_count:0,source_details:{season_audits:Object.fromEntries([...gamesByYear].map(([year,g])=>[year,{passed:true,finals:g.length,teams_with_82_games:completedSeason(year)?30:null}]))}},schedule_days_failed:[],
      data_quality:{complete_history_verified:true,validated_for_public_use:false,historical_replay_only:true,source_scope:'Manual user-selected files; file origin and underlying game results are NOT independently verified; not an automatic update',history_games:all.length,current_season_completed_games:currentGames.length}}
  }
  const region=document.createElement('section');region.className='file-lab';region.id='fileLab';region.setAttribute('aria-labelledby','fileLabHeading');
  region.innerHTML=`<div class="file-lab-copy"><span class="eyebrow">Data source / local research</span><h3 id="fileLabHeading">Bring the evidence.<br><em>Explore it.</em></h3><p>Use the licensed game-results CSV files from BoxScore Lab to run a historical backtest on your own device. Every file is checked for season completeness before a number appears, but <strong>file origin cannot be independently authenticated here.</strong> <b>No files are uploaded to a server.</b></p><a href="https://boxscorelab.com/downloads/" target="_blank" rel="noopener noreferrer">Find the original CSV downloads ↗</a></div><div class="file-lab-import"><label for="fileLabInput">Select the required team-game-results CSV files</label><input id="fileLabInput" type="file" accept=".csv,text/csv" multiple aria-describedby="fileLabRequirements"><p class="small" id="fileLabRequirements"></p><div class="file-lab-buttons"><button id="fileLabRun" class="btn" type="button">Audit files and evaluate the model</button><button id="fileLabDownload" class="btn secondary" type="button" disabled>Export research audit (.json)</button></div><div id="fileLabStatus" class="file-lab-status" role="status" aria-live="polite">No files selected. File format and coverage checks cannot verify a provider’s identity.</div><div id="fileLabOutput"></div></div>`;
  const target=$('researchAudit');if(target)target.before(region);
  $('fileLabRequirements').textContent='Required: '+expectedFiles().join(' · ')+'. Historical seasons must contain 1,230 games each. No file is saved or sent to a server.';
  // Direct links to the original, freely licensed source files. Keep these
  // distinct from the local upload control: visiting a download link never
  // implies a verified source, successful import, or automatic refresh.
  const sourceLinks=document.createElement('details');sourceLinks.className='file-lab-source-links';sourceLinks.open=true;
  const sourceSummary=document.createElement('summary');sourceSummary.textContent='Get the exact season CSV files';
  const sourceList=document.createElement('ul');
  for(const name of expectedFiles()){
    const li=document.createElement('li'),link=document.createElement('a');
    link.href='https://boxscorelab.com/downloads/'+encodeURIComponent(name);
    link.target='_blank';link.rel='noopener noreferrer';link.textContent=name;
    li.append(link);sourceList.append(li);
  }
  const sourceFootnote=document.createElement('p');sourceFootnote.className='small';
  sourceFootnote.textContent='Original files are hosted by BoxScore Lab under CC BY 4.0. Downloads do not automatically refresh this website; source records must still pass the audit.';
  sourceLinks.append(sourceSummary,sourceList,sourceFootnote);
  $('fileLabRequirements').after(sourceLinks);
  const run=$('fileLabRun'),download=$('fileLabDownload');let latestReport=null;
  download.addEventListener('click',()=>{
    if (!latestReport) return;
    const blob=new Blob([JSON.stringify(latestReport,null,2)+'\n'],{type:'application/json'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download='aureum-tipoff-local-research-audit.json';document.body.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  run.addEventListener('click',async()=>{
    run.disabled=true;$('fileLabOutput').replaceChildren();$('fileLabStatus').textContent='Auditing the selected CSVs locally…';
    try{
      const selected=[...$('fileLabInput').files],required=expectedFiles();
      if(selected.length!==required.length||new Set(selected.map(f=>f.name.toLowerCase())).size!==selected.length||required.some(name=>!selected.some(f=>f.name.toLowerCase()===name)))throw Error('Select exactly the required season files: '+required.join(', ')+'.');
      const by=new Map(),fileEvidenceManifest=[];
      for(const name of required){
        const file=selected.find(f=>f.name.toLowerCase()===name);
        if(file.size>6000000)throw Error(`${name} is too large to validate in-browser.`);
        const evidence=await fileEvidence(file);
        const games=parseGames(evidence.text,Number(name.slice(0,4)));
        by.set(Number(name.slice(0,4)),games);
        fileEvidenceManifest.push({name,bytes:evidence.bytes,sha256:evidence.sha256,validated_games:games.length});
      }
      const snapshot=buildSnapshot(by);
      if(typeof window.AureumApplyLocalSnapshot!=='function')throw Error('Data Desk is not ready to display imported research.');
      window.AureumApplyLocalSnapshot(snapshot);
      latestReport={report_type:'retrospective_local_browser_audit',source_identity_verified:false,
        explicitly_not_automatically_updated:true,generated_at:snapshot.generated_at,
        attribution:'User-supplied files claimed in BoxScore Lab format, https://boxscorelab.com/downloads/; CC BY 4.0 applies if authentic',
        file_names:required,file_evidence:fileEvidenceManifest,game_record_count:snapshot.data_quality.history_games,
        season_audits:snapshot.data_coverage.source_details.season_audits,
        model_settings:snapshot.model.settings,model_evaluation:snapshot.validation,
        note:'Structural audit of manually chosen files, not provider authentication, independent score verification, a live feed, or prospectively recorded predictions.'};
      download.disabled=false;
      $('fileLabStatus').textContent=`Structural checks passed: ${snapshot.data_quality.history_games.toLocaleString()} game records across ${required.length} seasons; ${snapshot.validation.holdout_2025_26.games} retrospective holdout games scored. Exact-byte SHA-256 fingerprints recorded for export; these do not authenticate the provider or individual scores. Browser-local only.`;
      const show=$('fileLabOutput');show.innerHTML=`<div class="file-lab-results"><div><span class="small">Retrospective winner accuracy</span><strong>${e((100*snapshot.validation.holdout_2025_26.accuracy).toFixed(1))}%</strong></div><div><span class="small">Brier score</span><strong>${e(snapshot.validation.holdout_2025_26.brier.toFixed(4))}</strong></div><div><span class="small">Current season games</span><strong>${e(snapshot.season_pulse.games)}</strong></div></div><p class="small">This is a historical reconstruction from user-selected files, not a prospective forecast, verified source, or live feed. The data stays in this tab until it is closed or refreshed.</p><details class="file-lab-provenance"><summary>Review imported file fingerprints (${fileEvidenceManifest.length} files)</summary><p class="small">SHA-256 is an exact-byte fingerprint for reproducing this local analysis. It does not prove that the files were published by BoxScore Lab or that their game scores are correct.</p><ul>${fileEvidenceManifest.map(f=>`<li><span>${e(f.name)} · ${f.validated_games.toLocaleString()} games</span><code>${e(f.sha256)}</code></li>`).join('')}</ul></details>`;
    }catch(err){$('fileLabStatus').textContent='Files not accepted: '+String(err.message||err).slice(0,320);}
    finally{run.disabled=false;}
  });
  window.AureumFileLab={csvParse,parseGames,buildSnapshot,expectedFiles};
})();
