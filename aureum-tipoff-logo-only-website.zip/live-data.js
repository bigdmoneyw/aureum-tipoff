/* Aureum Tipoff public research dashboard. No fictional scores or injury claims. */
(() => {
  'use strict';
  // Use the verified current-season official index. For future seasons, a
  // guessed seasonal URL is not evidence; fall back to the NBA official hub
  // until the independent report monitor confirms a real report URL.
  const easternSeason = (() => {
    const parts = new Intl.DateTimeFormat('en-US', {timeZone:'America/New_York',year:'numeric',month:'numeric'}).formatToParts(new Date());
    const year = Number(parts.find(p=>p.type==='year').value);
    const month = Number(parts.find(p=>p.type==='month').value);
    return month >= 10 ? year : year-1;
  })();
  const officialIndexFallback = easternSeason === 2026
    ? 'https://official.nba.com/nba-injury-report-2026-27-season/'
    : 'https://official.nba.com/';
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const section = document.createElement('section');
  section.className = 'page'; section.id = 'live';
  section.innerHTML = `
  <div class="wrap section">
    <div class="eyebrow">Aureum research / live data laboratory</div>
    <div class="studio-head"><div><h2>Every number has a record.</h2><p class="section-intro">Pregame basketball research with source timestamps, test results, and clear limitations. This page never substitutes made-up data when a feed is unavailable.</p></div><span class="pill gold">IN DEVELOPMENT · NOT LIVE</span></div>
    <div class="panel" style="margin-bottom:18px" role="status" aria-live="polite">
      <div class="live-status-top"><div><div class="kicker">Data integrity</div><strong id="liveStatus">Looking for a research snapshot…</strong><p id="liveUpdated" class="small"></p></div><span class="live-dot" id="liveDot" aria-hidden="true"></span></div>
      <div class="live-source" id="liveSource">Source and coverage appear when verified.</div>
    </div>
    <div class="research-recovery"><button type="button" class="btn secondary" id="liveRetry">Retry research data connection</button><span id="liveRetryHint" class="small" role="status">Only verified source snapshots are accepted. A retry does not create NBA data.</span></div>
    <div class="panel" id="verifiedGameSpotcheck" style="margin:18px 0" aria-live="polite"><div class="eyebrow">Verified source example · not a live feed</div><h3>Independent NBA score and schedule spot check</h3><p class="small">A dated cross-check of actual results and the league schedule. This is not a model backtest and it never produces prediction accuracy.</p><div id="verifiedSpotcheckBody" class="small">Checking the dated source sample…</div></div>
    <div class="audit-strip" id="researchAudit" aria-live="polite"><strong>Source audit pending</strong><span>Training coverage, source date, and outstanding evidence will appear here after a verified snapshot loads.</span></div>
    <div class="grid">
      <div class="card"><div class="kicker">Retrospective holdout · 2025–26</div><div class="stat" id="liveCount">—</div><p>Games scored before their results in historical replay</p></div>
      <div class="card"><div class="kicker">Elo winner accuracy</div><div class="stat" id="liveAccuracy">—</div><p>Correct selections in the fixed holdout</p></div>
      <div class="card"><div class="kicker">Elo Brier score</div><div class="stat" id="liveBrier">—</div><p>Probability error; lower is better</p></div>
    </div>
    <div class="panel" style="margin-top:18px"><div class="live-header"><div><div class="eyebrow">Forward-looking research</div><h3>Recorded pregame forecasts</h3><p class="small">The first recorded percentage is preserved when the daily data job runs again. These forecasts do <strong>not</strong> use injuries.</p></div><span class="pill" id="liveForecastCount">No records</span></div><div id="liveForecasts" class="live-games"><p class="notice">No verified forecasts available.</p></div></div>
    <div class="cols" style="margin-top:18px">
      <div class="panel"><div class="eyebrow">Holdout comparison</div><h3>Does the model beat a basic home-win benchmark?</h3><div id="liveBaseline" class="live-metric-list">Historical model and constant 50% baseline metrics are unavailable.</div><div id="liveUncertainty" class="notice" role="status">Uncertainty estimates appear after an audited historical holdout is available.</div><p class="small">The learned baseline uses only 2024–25 home-win outcomes. A positive Brier skill score means better probability estimates on the held-out 2025–26 season. Intervals use paired weekly blocks when game dates are known; they are not a guarantee of future performance.</p></div>
      <div class="panel"><div class="eyebrow">Timestamped record</div><h3>Prospective accountability</h3><div class="stat" id="liveProspective">—</div><p class="small" id="liveProspectiveText">No prospectively settled predictions yet.</p><div id="liveProspectiveDetail" class="live-metric-list"></div></div>
    </div>
    <div class="panel" style="margin-top:18px" id="eloLabPanel">
      <div class="live-header"><div><div class="eyebrow">Research / team-versus-team</div><h3>Rating Matchup Lab</h3><p class="small">Compare any two franchises represented by a current research snapshot. Choose the home team, and see how the recorded Elo ratings combine with the model's documented home-court setting.</p></div><span class="pill gold">DATA-BACKED SCENARIO · NOT A SCHEDULED GAME</span></div>
      <div class="elo-lab-controls"><label class="control" for="eloAway"><span class="small">Away franchise</span><select id="eloAway" disabled><option value="">Awaiting validated data</option></select></label><label class="control" for="eloHome"><span class="small">Home franchise</span><select id="eloHome" disabled><option value="">Awaiting validated data</option></select></label><button class="btn secondary" id="eloSwap" type="button" disabled>Switch home court ↔</button></div>
      <div id="eloLabResult" class="elo-lab-result" aria-live="polite"><div class="empty">No verified historical ratings loaded. Results won't be invented.</div></div>
      <div class="disclaimer"><b>Not a prediction for a scheduled NBA game.</b> This what-if comparison uses Elo team ratings from completed results and an estimated home advantage. It does not know tomorrow's lineup, current injuries, individual players, rest, or the location of a real future game.</div>
    </div>
    <div class="panel" style="margin-top:18px" id="seasonPulsePanel">
      <div class="live-header"><div><div class="eyebrow" id="pulseSeasonLabel">Current season / results desk</div><h3>Season Pulse</h3><p class="small" id="pulseSummary">Current-season records and recent results appear only when the data pipeline successfully retrieves complete results.</p></div><span class="pill gold" id="pulseGames">Awaiting feed</span></div>
      <div class="pulse-toolbar"><label class="control" for="pulseSearch"><span class="small">Find a team</span><input class="search-field" id="pulseSearch" type="search" placeholder="Team or abbreviation"></label><label class="control" for="pulseConference"><span class="small">Conference</span><select id="pulseConference"><option value="all">Both conferences</option><option value="East">Eastern</option><option value="West">Western</option></select></label><label class="control" for="pulseSort"><span class="small">Sort by</span><select id="pulseSort"><option value="pct">Win percentage</option><option value="margin">Point differential</option><option value="ppg">Points per game</option><option value="name">Team name</option></select></label></div>
      <div class="tablewrap"><table class="pulse-table"><caption>Current-season performance from completed NBA regular-season games; not official NBA standings or tie-breakers.</caption><thead><tr><th scope="col">Team</th><th scope="col">W–L</th><th scope="col">Win %</th><th scope="col">PPG</th><th scope="col">Opp PPG</th><th scope="col">Diff / G</th><th scope="col">Last 5</th></tr></thead><tbody id="pulseRows"><tr><td colspan="7">Awaiting real game results.</td></tr></tbody></table></div>
      <div class="research-actions"><button class="btn secondary" id="pulseExport" type="button" disabled>Export current-season team table (.csv)</button><span class="small" id="pulseExportStatus" role="status">Available only after real results load.</span></div>
      <p class="notice">Select a team to open its scouting card. Point differential is points scored minus points allowed per game. This is not an official ranking.</p>
      <div id="pulseSpotlight" class="pulse-spotlight" aria-live="polite"><p class="notice">Choose a team from the results table for its research profile.</p></div>
      <div class="pulse-results"><div><div class="eyebrow">Scores, not estimates</div><h3>Recent completed games</h3></div><div id="pulseRecent" class="pulse-recent"><p class="notice">No verified score data available.</p></div></div>
    </div>
    <div class="panel" style="margin-top:18px"><div class="eyebrow">Probability quality</div><h3>How well calibrated are the percentages?</h3><p class="small">Each band groups actual historical pregame home-win probabilities. A calibrated model predicts roughly the same home-win percentage that is observed. Small samples are noisy.</p><div id="liveCalibration" class="calibration-grid"><p class="notice">Historical calibration requires a real completed-game dataset.</p></div></div>
    <div class="panel" style="margin-top:18px"><div class="live-header"><div><div class="eyebrow">Team research</div><h3>Historical Elo ratings</h3></div><label class="control" for="liveTeamSearch"><span class="small">Find a franchise</span><input class="search-field" style="margin:0" id="liveTeamSearch" type="search" placeholder="Search team or abbreviation" autocomplete="off"></label></div><div id="liveTeamRatings" class="live-team-grid"><p class="notice">Verified ratings will appear after the data pipeline runs.</p></div><p class="small">Ratings summarize all completed regular-season games used since October 2024; historical wins and losses here are <strong>not</strong> current-season standings.</p></div>
    <div class="panel" style="margin-top:18px"><div class="live-header"><div><div class="eyebrow">Source monitoring</div><h3>Injury status board</h3></div><label class="control" for="liveInjuryTeam"><span class="small">Filter reports</span><select id="liveInjuryTeam"><option value="">All reported teams</option></select></label></div><div class="official-report-strip" id="officialInjuryReference" aria-live="polite"><div><div class="eyebrow">Official NBA source · independent of third-party data</div><strong id="officialReportTitle">Consult the league’s latest injury report</strong><p class="small" id="officialReportDesc">The NBA updates its reports throughout the day. Individual player statuses have not been imported or independently confirmed.</p></div><a class="research-link official-report-link" id="officialReportLink" href="https://official.nba.com/nba-injury-report-2026-27-season/" target="_blank" rel="noopener noreferrer">Open official NBA report index ↗</a></div><div class="official-player-section" aria-label="NBA-issued player statuses"><div class="official-player-toolbar"><div><div class="eyebrow">Official league report · player participation</div><strong id="officialPlayerCount">Awaiting an NBA-issued report</strong></div><label class="control" for="officialPlayerTeam"><span class="small">Filter official report by team</span><select id="officialPlayerTeam" disabled><option value="">All teams</option></select></label></div><p class="small" id="officialPlayerWarning">NBA-issued statuses, when verified and imported, are timestamped team reports—not confirmed lineups or injury-adjusted predictions.</p><div class="official-player-list" id="officialPlayerRows"><p class="notice">Player-level data has not yet been retrieved directly from an NBA-issued PDF.</p></div></div><div class="eyebrow" style="margin-top:25px">Additional third-party reports · unverified</div><p class="small" id="liveInjuryStatus">Awaiting a verified injury feed.</p><div id="liveInjuries" class="live-injuries"><p class="notice">No source-reported player statuses available.</p></div><p class="notice">Player status data comes from a third-party provider and has not been checked against the NBA’s official reporting. Injury statuses do not change Elo forecasts. Treat statuses as unconfirmed until compared with official NBA/team reporting. <a class="research-link" id="officialInjuryHelpLink" href="https://official.nba.com/" target="_blank" rel="noopener noreferrer">Consult NBA Official for the latest report ↗</a>.</p></div>
    <div class="panel" style="margin-top:18px"><div class="eyebrow">Open methodology</div><h3>What the forecast actually knows</h3><p id="liveMethod" class="notice">Elo method and data provenance will appear when a validated snapshot is available.</p><div class="live-proof"><div><strong>Historical replay</strong><p>Simulates pregame probabilities using earlier scores, but was reconstructed afterward.</p></div><div><strong>Prospective archive</strong><p>Stores the first percentage before a listed tipoff and settles it after the game ends.</p></div><div><strong>Independently checked?</strong><p>Not yet. Live source behavior, data licensing, browser QA, and archive integrity still require verification before publication.</p></div></div></div>
  </div>`;
  document.querySelector('main').appendChild(section);
  // The inline router initializes before this dynamically created page exists.
  if (location.hash === '#live' && typeof route === 'function') route();
  const nav = document.querySelector('.nav');
  const link = document.createElement('button'); link.dataset.page = 'live'; link.textContent = 'Data Desk';
  nav.insertBefore(link, [...nav.children].find(x => x.dataset.page === 'about') || null);
  link.addEventListener('click', () => { location.hash = 'live'; });
  const $ = id => document.getElementById(id);
  // The initial hash route runs before deferred scripts. Reapply it after the new page exists.
  if (location.hash === '#live' && typeof page === 'function') page('live');

  const fmtPercent = x => typeof x === 'number' && Number.isFinite(x) ? (x * 100).toFixed(1) + '%' : '—';
  const fmtScore = x => typeof x === 'number' && Number.isFinite(x) ? x.toFixed(4) : '—';
  const fmtDate = x => { const date = new Date(x); return Number.isNaN(date.getTime()) ? 'Unknown date' : date.toLocaleString(undefined, {month:'short', day:'numeric', hour:'numeric', minute:'2-digit', timeZoneName:'short'}); };
  const fullName = code => (typeof name === 'function' ? name(code) : code);

  function renderMetrics(d) {
    const v = d.validation || {}, hold = v.holdout_2025_26 || {}, base = v.baseline_2025_26 || {}, learned = v.learned_home_baseline_2025_26 || {};
    $('liveCount').textContent = hold.games || '—';
    $('liveAccuracy').textContent = fmtPercent(hold.accuracy);
    $('liveBrier').textContent = fmtScore(hold.brier);
    $('liveMethod').textContent = v.method || 'Methodology unavailable.';
    $('liveBaseline').innerHTML = `<div class="live-measure"><span>Tested games</span><strong>${esc(hold.games ?? '—')}</strong></div>
      <div class="live-measure"><span>Model accuracy</span><strong>${fmtPercent(hold.accuracy)}</strong></div>
      <div class="live-measure"><span>50% baseline accuracy</span><strong>${fmtPercent(base.accuracy)}</strong></div>
      <div class="live-measure"><span>Model Brier</span><strong>${fmtScore(hold.brier)}</strong></div>
      <div class="live-measure"><span>50% baseline Brier</span><strong>${fmtScore(base.brier)}</strong></div>
      <div class="live-measure"><span>Training-season home win rate</span><strong>${fmtPercent(v.training_home_rate)}</strong></div>
      <div class="live-measure"><span>Training-based baseline Brier</span><strong>${fmtScore(learned.brier)}</strong></div>
      <div class="live-measure"><span>Brier skill vs stronger baseline</span><strong>${v.brier_skill_vs_learned_baseline == null ? '—' : esc((v.brier_skill_vs_learned_baseline*100).toFixed(1))+'%'}</strong></div>`;
    const interval = v.holdout_uncertainty_2025_26;
    const validInterval = interval && Number.isInteger(interval.games) && interval.games >= 100 &&
      Array.isArray(interval.brier_improvement_95pct_interval) && interval.brier_improvement_95pct_interval.length === 2 &&
      interval.brier_improvement_95pct_interval.every(x => Number.isFinite(x)) &&
      Array.isArray(interval.winner_accuracy_95pct_interval) && interval.winner_accuracy_95pct_interval.length === 2 &&
      interval.winner_accuracy_95pct_interval.every(x => Number.isFinite(x));
    $('liveUncertainty').textContent = validInterval
      ? `Historical holdout uncertainty: Brier improvement vs the training-season baseline ${fmtScore(interval.brier_improvement)} ` +
        `(95% resampling interval ${fmtScore(interval.brier_improvement_95pct_interval[0])} to ${fmtScore(interval.brier_improvement_95pct_interval[1])}). ` +
        `Winner accuracy interval ${fmtPercent(interval.winner_accuracy_95pct_interval[0])} to ${fmtPercent(interval.winner_accuracy_95pct_interval[1])}. ` +
        `This is a descriptive ${esc(interval.resampling_unit || 'game-level resampling')} interval, not a guarantee of new-season performance.`
      : 'No credible uncertainty interval is available. At least 100 valid held-out games and a training-season baseline are required.';
    const pros = d.prospective_validation || {};
    $('liveProspective').textContent = pros.games || '0';
    $('liveProspectiveText').textContent = `Forecasts recorded before tipoff and subsequently settled. ${esc(d.forecast_archive_count ?? 0)} total entries in the research archive.`;
    $('liveProspectiveDetail').innerHTML = `<div class="live-measure"><span>Correct winners</span><strong>${fmtPercent(pros.accuracy)}</strong></div><div class="live-measure"><span>Brier error</span><strong>${fmtScore(pros.brier)}</strong></div>`;
  }
  function renderForecasts(d) {
    const list = (d.forecasts || []).filter(x => x && prob(x.home_probability) && time(x.tipoff) && time(x.first_recorded_at) && Date.parse(x.first_recorded_at) < Date.parse(x.tipoff) && Date.parse(x.tipoff) > Date.now()).sort((a,b)=>Date.parse(a.tipoff)-Date.parse(b.tipoff)).slice(0, 30);
    $('liveForecastCount').textContent = `${list.length} scheduled`;
    $('liveForecasts').innerHTML = list.length ? list.map(g => {
      const home = (g.home_probability * 100).toFixed(1);
      const edge = (d.model?.settings?.home_advantage ?? 0);
      const gap = Number.isFinite(g.home_rating) && Number.isFinite(g.away_rating) ? g.home_rating - g.away_rating : null;
      const reason = gap === null ? 'Ratings unavailable for decomposition' : `Home rating ${esc(g.home_rating)}, away rating ${esc(g.away_rating)} (difference ${gap>0?'+':''}${gap}); modeled home advantage +${esc(edge)} Elo points`;
      return `<article class="live-game"><div class="live-game-main"><div class="small">${esc(fmtDate(g.latest_tipoff || g.tipoff))} · <span>Recorded ${esc(fmtDate(g.first_recorded_at))}</span></div><strong>${esc(fullName(g.away))} <span class="muted">at</span> ${esc(fullName(g.home))}</strong><div class="small">${reason}</div><div class="small">Elo baseline · no injury, rotation or pace adjustment${g.schedule_changed?' · schedule changed; excluded from clean prospective validation':''}</div></div><div class="live-prob"><b>${home}%</b><span class="small">Home win estimate</span><div class="live-prob-track"><div style="width:${Math.max(0, Math.min(100, g.home_probability * 100))}%"></div></div></div></article>`;
    }).join('') : '<p class="notice">There are no upcoming forecasts from a verified snapshot. No probabilities have been invented.</p>';
  }
  function renderTeams(d) {
    const items = Object.entries(d.teams || {}).map(([code,t]) => ({code, ...t})).sort((a,b)=> b.rating - a.rating);
    const draw = () => {
      const q = $('liveTeamSearch').value.trim().toLowerCase();
      const filtered = items.filter(t => (t.code + ' ' + fullName(t.code)).toLowerCase().includes(q));
      $('liveTeamRatings').innerHTML = filtered.length ? filtered.map((t,i) => `<div class="live-team"><div class="live-team-abbr">${esc(t.code)}</div><div><strong>${esc(fullName(t.code))}</strong><div class="small">${esc(t.historical_wins)} wins · ${esc(t.historical_losses)} losses in research history</div></div><div class="live-team-rating">${esc(t.rating)}</div></div>`).join('') : '<p class="notice">No matching franchises in the verified snapshot.</p>';
    };
    $('liveTeamSearch').oninput = draw;
    draw();
  }

  // This is a rating-only, user-selected what-if. It NEVER enters the prospective archive.
  function renderEloLab(d) {
    const settings = d.model?.settings || {};
    const edge = Number(settings.home_advantage), scale = Number(settings.logistic_scale);
    const ranked = Object.entries(d.teams || {}).filter(([code,t]) =>
      typeof code === 'string' && code.length <= 4 && Number.isFinite(t?.rating) &&
      typeof fullName(code) === 'string').sort((a,b) => fullName(a[0]).localeCompare(fullName(b[0])));
    if (ranked.length < 2 || !Number.isFinite(edge) || !Number.isFinite(scale) || scale <= 0) {
      $('eloLabResult').innerHTML = '<div class="empty">At least two sourced team Elo ratings and valid model settings are needed. No scenario can be calculated.</div>';
      return;
    }
    for (const id of ['eloAway','eloHome']) {
      const e = $(id);
      e.innerHTML = ranked.map(([code])=>`<option value="${esc(code)}">${esc(fullName(code))}</option>`).join('');
      e.disabled = false;
    }
    $('eloAway').value = ranked[0][0];
    $('eloHome').value = ranked[1][0];
    $('eloSwap').disabled = false;
    const draw = () => {
      const a = $('eloAway').value, h = $('eloHome').value;
      if (a === h) {
        $('eloLabResult').innerHTML='<div class="empty">Choose two different NBA teams to compare.</div>';
        return;
      }
      const away = d.teams[a]?.rating, home = d.teams[h]?.rating;
      if (!Number.isFinite(away) || !Number.isFinite(home)) return;
      const difference = home - away, ratingEdge = difference + edge;
      const p = 1 / (1 + Math.pow(10, -ratingEdge/scale));
      if (!Number.isFinite(p)) return;
      const pct = (p*100).toFixed(1), other = ((1-p)*100).toFixed(1);
      $('eloLabResult').innerHTML = `<div class="elo-lab-score"><div><span class="small">${esc(fullName(a))} · away</span><strong>${other}%</strong></div><span class="versus">VS</span><div><span class="small">${esc(fullName(h))} · home</span><strong>${pct}%</strong></div></div>
        <div class="elo-lab-track" role="img" aria-label="Hypothetical probabilities: ${esc(fullName(a))} ${other}%, ${esc(fullName(h))} ${pct}%"><div style="width:${(100*p).toFixed(3)}%"></div></div>
        <div class="elo-explain"><span><b>${esc(Math.round(home))}</b> home Elo</span><span><b>${esc(Math.round(away))}</b> away Elo</span><span><b>${difference>=0?'+':''}${esc(Math.round(difference))}</b> rating gap</span><span><b>${edge>=0?'+':''}${esc(edge)}</b> home-court points</span></div>
        <p class="notice">The home rating is ${Math.abs(Math.round(difference))} points ${difference >= 0 ? 'higher' : 'lower'} than the away rating. Adding ${esc(edge)} modeled home-court points produces a net ${ratingEdge >= 0 ? 'home' : 'away'} edge of ${esc(Math.abs(Math.round(ratingEdge)))} Elo points. Converting that to a probability using scale ${esc(scale)} gives ${pct}% for the home team under these assumptions.</p>`;
    };
    ['eloAway','eloHome'].forEach(id=>$(id).onchange = draw);
    $('eloSwap').onclick = ()=>{const a=$('eloAway').value; $('eloAway').value=$('eloHome').value; $('eloHome').value=a;draw();};
    draw();
  }

  function renderAudit(d) {
    const source = d.data_coverage || {};
    const quality = d.data_quality || {};
    const audits = source.source_details?.season_audits || {};
    const seasonYear = Number(d.season?.slice(0,4));
    const ny = Number(new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',month:'numeric'}).format(new Date()));
    const lastCompleted = ny >= 7 && ny <= 9 ? seasonYear : seasonYear - 1;
    const finished = Number.isInteger(lastCompleted) && lastCompleted >= 2025
      ? Array.from({length:lastCompleted-2024+1},(_,i)=>2024+i) : [];
    const full = finished.length > 0 && finished.every(y => audits[String(y)]?.passed === true && audits[String(y)]?.finals === 1230 && audits[String(y)]?.teams_with_82_games === 30);
    const scored = d.validation?.holdout_2025_26?.games || 0;
    const forecasts = d.prospective_validation?.games || 0;
    const facts = [
      ['Historical season audits', full ? finished.length+' complete seasons' : 'Not independently confirmed'],
      ['Retrospective holdout', `${scored} games evaluated`],
      ['Prospectively settled', `${forecasts} archived game forecasts`],
      ['Injury verification', 'Not independently confirmed'],
      ['Newest completed game in dataset', d.data_through ? fmtDate(d.data_through) : 'No completed game recorded for this season'],
      [source.adapter === 'boxscorelab' ? 'Local CSV audit completed' : source.adapter === 'local_browser_manual_import' ? 'Local files evaluated' : 'Source checked at', fmtDate(d.source_checked_at || d.generated_at)],
      ['Snapshot generated', fmtDate(d.generated_at)]
    ];
    $('researchAudit').innerHTML = facts.map(([label,value])=>`<div><span class="small">${esc(label)}</span><strong>${esc(value)}</strong></div>`).join('');
    if (quality.historical_replay_only) $('researchAudit').setAttribute('aria-label','Retrospective dataset only; no verified future games or injuries');
  }

  function enableExport(d) {
    const pulse = d.season_pulse;
    if (!pulse || !pulse.teams || !pulse.games) return;
    const button = $('pulseExport'); button.disabled = false;
    button.onclick = () => {
      const rows = [['Team','Code','Season','Wins','Losses','Win percentage','Points per game','Opponent points per game','Point differential per game','Data source / license','Latest completed game (UTC)','Snapshot generated (UTC)']];
      for (const [code,t] of Object.entries(pulse.teams).sort((a,b)=>fullName(a[0]).localeCompare(fullName(b[0])))) {
        rows.push([fullName(code), code, pulse.season, t.wins, t.losses, t.win_pct ?? '', t.ppg ?? '', t.opp_ppg ?? '', t.point_diff ?? '', d.source, d.data_through || '', d.generated_at]);
      }
      const cell = x => '"' + String(x ?? '').replace(/"/g,'""') + '"';
      // Prefix potential spreadsheet formulas, keeping a human-readable plain CSV export.
      const safe = x => /^[=+@\-]/.test(String(x).trimStart()) && typeof x === 'string' ? "'"+x : x;
      const csv = rows.map(r=>r.map(v=>cell(safe(v))).join(',')).join('\r\n')+'\r\n';
      const blob = new Blob([csv],{type:'text/csv;charset=utf-8'});
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=url;a.download=`aureum-tipoff-team-records-${pulse.season}.csv`;
      document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);
      $('pulseExportStatus').textContent='Exported recorded season totals; source: '+d.source+'.';
    };
    $('pulseExportStatus').textContent='Includes real completed-game aggregates only; confirm source attribution before sharing.';
  }

  function renderPulse(d) {
    const pulse = d.season_pulse;
    if (!pulse || !pulse.teams || !Array.isArray(pulse.recent_games)) return;
    $('pulseGames').textContent = `${pulse.games} completed games`;
    $('pulseSummary').textContent = `${pulse.season} regular-season games only. All figures are computed from final scores in the imported dataset.`;
    const entries = Object.entries(pulse.teams).map(([code, record]) => ({code, ...record}));
    const showTeam = code => {
      const t = pulse.teams[code];
      if (!t) return;
      const elo = d.teams?.[code]?.rating;
      const games = t.wins + t.losses;
      const last = t.last_game;
      $('pulseSpotlight').innerHTML = `<div class="eyebrow">Season scouting card</div><h3>${esc(fullName(code))}</h3>
        <div class="pulse-spotlight-grid">
        <div><div class="small">Win–loss record</div><strong>${esc(t.wins)}–${esc(t.losses)}</strong><p class="small">${games} completed regular-season games</p></div>
        <div><div class="small">Points per game</div><strong>${t.ppg == null ? '—' : esc(t.ppg)}</strong><p class="small">Opponents: ${t.opp_ppg == null ? '—' : esc(t.opp_ppg)}</p></div>
        <div><div class="small">Elo rating</div><strong>${Number.isFinite(elo) ? esc(elo) : '—'}</strong><p class="small">Relative model rating, not a league rank</p></div></div>
        <div class="pulse-points"><span>Scored ${t.ppg == null ? '—' : esc(t.ppg)} / game</span><span>Allowed ${t.opp_ppg == null ? '—' : esc(t.opp_ppg)} / game</span></div>
        <div class="pulse-two-track"><div style="width:${t.ppg && t.opp_ppg ? Math.max(0,Math.min(100,100*t.ppg/(t.ppg+t.opp_ppg))) : 50}%"></div></div>
        <p class="small">${last ? `Last game ${esc(last.date)}: ${esc(last.result)} ${esc(last.scored)}–${esc(last.allowed)} ${last.place==='home'?'vs':'at'} ${esc(fullName(last.opponent))}.` : 'No regular-season results recorded for this team.'} Form over last five: ${esc(t.last_five || '—')}. Ratings include earlier completed seasons; the season record does not.</p>`;
    };
    $('pulseRows').onclick = e => {
      const selected = e.target.closest('[data-pulse-team]');
      if (selected) showTeam(selected.dataset.pulseTeam);
    };
    const draw = () => {
      const query = $('pulseSearch').value.trim().toLowerCase();
      const conf = $('pulseConference').value;
      const sort = $('pulseSort').value;
      const shown = entries.filter(t =>
        (t.code + ' ' + fullName(t.code)).toLowerCase().includes(query) &&
        (conf === 'all' || (typeof info === 'function' && info(t.code)?.[3] === conf))
      );
      shown.sort((a,b) => {
        if (sort === 'name') return fullName(a.code).localeCompare(fullName(b.code));
        const key = sort === 'margin' ? 'point_diff' : sort === 'ppg' ? 'ppg' : 'win_pct';
        return (b[key] ?? -Infinity) - (a[key] ?? -Infinity) || fullName(a.code).localeCompare(fullName(b.code));
      });
      $('pulseRows').innerHTML = shown.length ? shown.map(t => `<tr><th scope="row"><button class="pulse-team-link" type="button" data-pulse-team="${esc(t.code)}" aria-label="Open ${esc(fullName(t.code))} season research profile">${esc(fullName(t.code))}</button></th><td>${esc(t.wins)}–${esc(t.losses)}</td><td>${fmtPercent(t.win_pct)}</td><td>${t.ppg == null ? '—' : esc(t.ppg.toFixed(1))}</td><td>${t.opp_ppg == null ? '—' : esc(t.opp_ppg.toFixed(1))}</td><td class="${(t.point_diff || 0)>0?'positive':''}">${t.point_diff == null ? '—' : (t.point_diff>0?'+':'')+esc(t.point_diff.toFixed(1))}</td><td><span class="pulse-form">${esc(t.last_five || '—')}</span><div class="small">${esc(t.streak || '—')}</div></td></tr>`).join('') : '<tr><td colspan="7">No teams match that filter.</td></tr>';
    };
    ['pulseSearch','pulseConference','pulseSort'].forEach(id => {$(id)[id === 'pulseSearch' ? 'oninput' : 'onchange'] = draw;});
    draw();
    $('pulseRecent').innerHTML = pulse.recent_games.length ? pulse.recent_games.map(g=> {
      const hWin = g.home_score > g.away_score;
      return `<article class="pulse-score"><span class="small">${esc(g.date.slice(0,10))}</span><span>${esc(fullName(g.away))} <b class="${!hWin?'positive':''}">${esc(g.away_score)}</b></span><span>${esc(fullName(g.home))} <b class="${hWin?'positive':''}">${esc(g.home_score)}</b></span></article>`;
    }).join('') : '<p class="notice">No completed regular-season games were returned for this season.</p>';
  }
  function renderCalibration(d) {
    const rows = d.validation?.holdout_calibration || [];
    $('liveCalibration').innerHTML = rows.length ? rows.map(bucket => {
      const pred = bucket.mean_prediction;
      const actual = bucket.observed_home_win;
      return `<div class="calibration-card"><div class="eyebrow">${esc(bucket.label)} predicted</div><strong>${esc(bucket.games)} games</strong><div class="small">Average forecast: ${fmtPercent(pred)}</div><div class="small">Actual home wins: ${fmtPercent(actual)}</div><div class="calibration-track" role="img" aria-label="Predicted ${fmtPercent(pred)}, observed ${fmtPercent(actual)}"><div style="width:${Math.min(100,Math.max(0,(pred??0)*100))}%"></div><span style="left:${Math.min(100,Math.max(0,(actual??0)*100))}%"></span></div></div>`;
    }).join('') : '<p class="notice">Calibration awaits verified historical scores.</p>';
  }
  function renderInjuries(d) {
    const reports = Array.isArray(d.injuries) ? d.injuries : [];
    $('liveInjuryStatus').textContent = d.injury_source_status === 'retrieved_unverified'
      ? `Third-party injury statuses retrieved ${fmtDate(d.injury_retrieved_at)}. Official team/game participation must still be confirmed.`
      : 'Injury feed unavailable; no player status is inferred.';
    const options = [...new Set(reports.map(x => x.team).filter(Boolean))].sort();
    $('liveInjuryTeam').innerHTML = '<option value="">All reported teams</option>' + options.map(c=>`<option value="${esc(c)}">${esc(fullName(c))}</option>`).join('');
    const draw = () => {
      const team = $('liveInjuryTeam').value;
      const rows = reports.filter(x => !team || x.team === team).slice(0, 150);
      $('liveInjuries').innerHTML = rows.length ? rows.map(r => `<div class="item"><span><strong>${esc(r.player)}</strong><span class="small"> · ${esc(r.team)}</span>${r.detail ? `<div class="small">${esc(r.detail)}</div>` : ''}</span><span class="pill">${esc(r.status)}</span></div>`).join('') : '<p class="notice">No source-reported injury entries available. Do not infer full availability.</p>';
    };
    $('liveInjuryTeam').onchange = draw;
    draw();
  }

  // A broken feed must never partially render as trustworthy basketball data.
  // Keep validation in the browser too: cached/static JSON may be stale or corrupt.
  const knownCodes = new Set((typeof teams !== 'undefined' ? teams : []).map(t => t[0]));
  const validCode = code => typeof code === 'string' && knownCodes.has(code);
  const integer = n => Number.isInteger(n) && n >= 0;
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const prob = n => finite(n) && n >= 0 && n <= 1;
  const time = input => typeof input === 'string' && Number.isFinite(Date.parse(input)) && /(?:Z|[+-]\d{2}:\d{2})$/i.test(input);
  function validateSnapshot(d) {
    if (!d || typeof d !== 'object' || Array.isArray(d) || d.schema_version !== 2 ||
        !time(d.generated_at) || typeof d.source !== 'string' || !d.source.trim() ||
        typeof d.season !== 'string' || !/^20\d{2}-\d{2}$/.test(d.season) ||
        !d.validation || typeof d.validation !== 'object' || !d.model || typeof d.model !== 'object' ||
        !d.data_coverage || typeof d.data_coverage !== 'object') {
      throw Error('Invalid research snapshot structure or source metadata.');
    }
    if (d.data_through != null && (!time(d.data_through) || Date.parse(d.data_through) > Date.now() + 3600000))
      throw Error('Source result date is malformed or in the future.');
    if (d.source_checked_at != null && !time(d.source_checked_at))
      throw Error('Source check timestamp is malformed.');
    if (d.data_coverage.failure_count !== undefined && !integer(d.data_coverage.failure_count))
      throw Error('Invalid data-provider failure count.');
    if (d.schedule_days_failed !== undefined && !Array.isArray(d.schedule_days_failed))
      throw Error('Invalid schedule coverage report.');
    const settings = d.model.settings;
    if (!settings || !finite(settings.home_advantage) || !finite(settings.logistic_scale) || settings.logistic_scale <= 0)
      throw Error('Missing valid model settings.');
    if (!d.teams || typeof d.teams !== 'object' || Array.isArray(d.teams))
      throw Error('Missing team research records.');
    if (Object.keys(d.teams).length < 2) throw Error('Insufficient sourced team ratings.');
    for (const [code, record] of Object.entries(d.teams)) {
      if (!validCode(code) || !record || !finite(record.rating))
        throw Error('Team research ratings failed validation.');
    }
    if (d.season_pulse == null) throw Error('Current-season research summary is missing.');
    {
      const pulse = d.season_pulse;
      if (typeof pulse !== 'object' || !integer(pulse.games) || !pulse.teams ||
          typeof pulse.teams !== 'object' || !Array.isArray(pulse.recent_games))
        throw Error('Invalid current-season result summary.');
      for (const [code, rec] of Object.entries(pulse.teams)) {
        if (!validCode(code) || !rec || !integer(rec.wins) || !integer(rec.losses) ||
            ['win_pct','ppg','opp_ppg','point_diff'].some(k => rec[k] != null && !finite(rec[k])) ||
            (rec.win_pct != null && !prob(rec.win_pct)) ||
            (rec.ppg != null && rec.ppg < 0) || (rec.opp_ppg != null && rec.opp_ppg < 0))
          throw Error('Current-season team values failed validation.');
      }
      for (const g of pulse.recent_games) {
        if (!g || !validCode(g.home) || !validCode(g.away) || g.home === g.away ||
            !integer(g.home_score) || !integer(g.away_score) || typeof g.date !== 'string')
          throw Error('Recent game results failed validation.');
      }
    }
    if (d.forecasts != null && !Array.isArray(d.forecasts))
      throw Error('Forecast list is malformed.');
    for (const f of d.forecasts || []) {
      if (!f || !validCode(f.home) || !validCode(f.away) || f.home === f.away ||
          !prob(f.home_probability) || !time(f.tipoff) || !time(f.first_recorded_at) ||
          Date.parse(f.first_recorded_at) >= Date.parse(f.tipoff))
        throw Error('A forecast was not a valid pre-tipoff record.');
    }
    if (d.injuries != null && !Array.isArray(d.injuries))
      throw Error('Injury list is malformed.');
    return d;
  }

  function clearResearch() {
    window.AureumSnapshot = null;
    window.dispatchEvent(new Event('aureum:data-unavailable'));
    for (const id of ['liveCount','liveAccuracy','liveBrier','liveProspective']) $(id).textContent = '—';
    $('liveBaseline').textContent = 'Historical model metrics are unavailable.';
    $('liveUncertainty').textContent = 'No audited holdout uncertainty estimates are available.';
    $('liveProspectiveText').textContent = 'No verified pregame outcomes available.';
    $('liveProspectiveDetail').replaceChildren();
    $('liveForecastCount').textContent = 'No records';
    $('liveForecasts').innerHTML = '<p class="notice">No verified pregame forecasts are available.</p>';
    $('pulseSeasonLabel').textContent = 'Current season / results desk';
    $('pulseGames').textContent = 'Awaiting feed';
    $('pulseSummary').textContent = 'Team statistics require a validated data snapshot.';
    $('pulseRows').innerHTML = '<tr><td colspan="7">Awaiting real game results.</td></tr>';
    $('pulseRecent').innerHTML = '<p class="notice">No verified results available.</p>';
    $('pulseSpotlight').innerHTML = '<p class="notice">Choose a team after a sourced feed is loaded.</p>';
    $('pulseExport').disabled = true;
    $('pulseExport').onclick = null;
    $('pulseExportStatus').textContent = 'Available only after real results load.';
    $('researchAudit').innerHTML = '<strong>Source audit pending</strong><span>No current verified snapshot.</span>';
    $('liveCalibration').textContent = 'Historical calibration is unavailable.';
    $('liveTeamRatings').textContent = 'Team ratings require a verified snapshot.';
    $('liveInjuryStatus').textContent = 'Injury feed unavailable; no player status is inferred.';
    $('liveInjuries').textContent = 'No verified reports loaded.';
    $('liveInjuryTeam').innerHTML = '<option value="">All reported teams</option>';
    $('liveMethod').textContent = 'Elo method and data provenance await a validated snapshot.';
    for (const id of ['eloAway','eloHome']) {
      $(id).disabled = true;
      $(id).innerHTML = '<option value="">Awaiting validated data</option>';
    }
    $('eloSwap').disabled = true;
    $('eloLabResult').textContent = 'At least two sourced team ratings are required.';
  }

  let loading = false;
  let manualLoaded = false;
  function displaySnapshot(d, manual=false) {
    validateSnapshot(d);
    const age = (Date.now() - Date.parse(d.generated_at)) / 3600000;
    if (!Number.isFinite(age) || age < -1 || age > 24) throw Error('The research snapshot is missing or stale (more than 24 hours old).');
    if (d.data_coverage?.failure_count || (d.schedule_days_failed || []).length) throw Error('The provider did not return complete schedule/history coverage.');
    $('liveStatus').textContent = manual ? 'Local CSV historical research loaded · not a live update' : 'Source data loaded · research use only, independent verification pending';
    $('liveRetryHint').textContent = manual ? 'Manual files stay in this browser tab only. To return to the automated source, use Retry.' : 'Research data loaded. You can check for updated records whenever needed.';
    $('liveDot').classList.add('live-dot-ok');
    $('liveUpdated').textContent = 'Snapshot generated ' + new Date(d.generated_at).toLocaleString()
      + (d.data_through ? ' · Most recent completed game: ' + new Date(d.data_through).toLocaleDateString() : ' · No completed game date is available for this season');
    $('liveSource').textContent = d.source + ' · ' + d.season + ' season · ' + (d.data_coverage?.dates_cached ?? '—') + ' days represented. ' + (manual ? 'MANUAL BROWSER IMPORT. No automatic updates, schedules, pregame forecasts, verified player statuses, or server storage.' : d.data_quality?.historical_replay_only ? 'Retrospective scores and model evaluation only: no upcoming pregame predictions, live player statuses or verified tipoff times.' : 'Third-party provider data and player statuses are not independently verified.');
    $('pulseSeasonLabel').textContent = d.season + ' / results desk';
    renderMetrics(d);renderForecasts(d);renderPulse(d);renderCalibration(d);renderTeams(d);renderInjuries(d);renderEloLab(d);renderAudit(d);enableExport(d);
    window.AureumSnapshot = d;
    window.dispatchEvent(new CustomEvent('aureum:data-ready', {detail:{snapshot:d}}));
  }
  window.AureumApplyLocalSnapshot = d => {
    // Only allow this explicit local user action to switch the research view.
    const checked = validateSnapshot(d);
    if (checked.data_coverage?.adapter !== 'local_browser_manual_import' || checked.data_quality?.historical_replay_only !== true || checked.forecasts?.length || checked.injuries != null)
      throw Error('Only completed-game, browser-local research imports are permitted here.');
    displaySnapshot(checked,true);
    manualLoaded = true;
  };
  async function load() {
    if (loading) return;
    loading = true;
    $('liveRetry').disabled = true;
    $('liveRetryHint').textContent = 'Checking the latest stored research snapshot…';
    const controller = new AbortController();
    const deadline = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch('./data/nba.json?nocache=' + Date.now(), {cache:'no-store', signal:controller.signal});
      if(!response.ok) throw Error('The research snapshot has not been generated.');
      const d = validateSnapshot(await response.json());
      if (!manualLoaded) displaySnapshot(d);
    } catch (e) {
      if (!manualLoaded) {
        clearResearch();
        $('liveStatus').textContent = 'NBA data feed not available yet';
        $('liveDot').classList.remove('live-dot-ok');
        $('liveRetryHint').textContent = 'You can retry the source connection. Other educational features remain usable offline.';
        $('liveUpdated').textContent = 'Data pipeline status: '+e.message;
        $('liveSource').textContent = 'The interface is ready, but no real-time statistics or predictions are claimed. See Development Notes in the project for activation requirements.';
      }
    } finally {
      clearTimeout(deadline);
      loading = false;
      $('liveRetry').disabled = false;
    }
  }
  // This official report is independent of results and third-party feeds.
  // Every displayed player status must come from a recent NBA-hosted PDF;
  // missing player rows NEVER imply availability.
  async function loadOfficialReport() {
    const resetOfficial = () => {
      $('officialReportTitle').textContent = 'Consult the league’s latest injury report';
      $('officialReportDesc').textContent = 'The NBA updates reports throughout the day. Open its index for the latest report; no player status is being inferred.';
      $('officialReportLink').href = officialIndexFallback;
      $('officialReportLink').textContent = easternSeason === 2026 ? 'Open official NBA report index ↗' : 'Find the current report at NBA Official ↗';
      $('officialPlayerCount').textContent = 'No current NBA-issued player statuses imported';
      $('officialPlayerWarning').textContent = 'Missing reports, unsubmitted team information, and players not listed are NOT evidence of availability.';
      $('officialPlayerRows').innerHTML = '<p class="notice">Read the original NBA report for current player statuses. No entries have been verified for display.</p>';
      $('officialPlayerTeam').disabled = true;
      $('officialPlayerTeam').innerHTML = '<option value="">All teams</option>';
      $('officialPlayerTeam').onchange = null;
    };
    resetOfficial();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);
    try {
      const response = await fetch('./data/official_injury_reference.json?nocache=' + Date.now(), {cache:'no-store',signal:controller.signal});
      if (!response.ok) throw Error('No official report link file');
      const ref = await response.json();
      const validUrl = typeof ref?.report_url === 'string' &&
        /^https:\/\/ak-static\.cms\.nba\.com\/referee\/injury\/Injury-Report_20\d{2}-\d{2}-\d{2}_\d{2}_\d{2}(?:AM|PM)\.pdf$/i.test(ref.report_url);
      if (ref?.schema_version !== 1 || !['official_report_link_only','official_report_player_statuses'].includes(ref.status) || !validUrl)
        throw Error('Unexpected official report source');
      const issued = Date.parse(ref.report_issued_at);
      const checked = Date.parse(ref.checked_at);
      if (!Number.isFinite(issued) || !Number.isFinite(checked) ||
          issued > Date.now() + 15 * 60000 || Date.now() - issued > 36 * 3600000 ||
          checked > Date.now() + 15 * 60000 || Date.now() - checked > 24 * 3600000)
        throw Error('Official report link is too old');
      // The claimed issue time must match the timestamp INSIDE the NBA PDF URL.
      // Prevent a recently edited JSON file from presenting an old report as fresh.
      const dateParts = new Intl.DateTimeFormat('en-US', {
        timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit',
        hour:'2-digit',minute:'2-digit',hour12:true
      }).formatToParts(new Date(issued));
      const stamp = Object.fromEntries(dateParts.filter(p=>p.type!=='literal').map(p=>[p.type,p.value]));
      const expectedTail = `Injury-Report_${stamp.year}-${stamp.month}-${stamp.day}_${stamp.hour}_${stamp.minute}${stamp.dayPeriod.toUpperCase()}.pdf`;
      if (ref.report_url.slice(ref.report_url.lastIndexOf('/')+1).toUpperCase() !== expectedTail.toUpperCase())
        throw Error('NBA report issue time does not match the original PDF');
      $('officialReportTitle').textContent = 'NBA-issued report · ' + new Date(issued).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit',timeZone:'America/New_York',timeZoneName:'short'});
      $('officialReportDesc').textContent = 'Original NBA-hosted PDF. Reports may change throughout the day and some teams may not have submitted information yet.';
      $('officialReportLink').href = ref.report_url;
      $('officialReportLink').textContent = 'Read original NBA report ↗';
      if (ref.status !== 'official_report_player_statuses') return;
      const statuses = ref.player_statuses;
      const permitted = new Set(['Out','Doubtful','Questionable','Probable','Available']);
      if (!Array.isArray(statuses) || !statuses.length || statuses.length > 800 ||
          !statuses.every(p=>p && validCode(p.team) && typeof p.player==='string' &&
            p.player.length > 2 && p.player.length < 110 && permitted.has(p.status) &&
            typeof p.reason==='string' && p.reason.length < 360 &&
            typeof p.matchup==='string' && /^[A-Z]{2,3}@[A-Z]{2,3}$/.test(p.matchup) &&
            p.matchup.split('@').includes(p.team) &&
            (p.game_date == null || (typeof p.game_date === 'string' &&
              /^20\d{2}-\d{2}-\d{2}$/.test(p.game_date) &&
              !Number.isNaN(Date.parse(p.game_date))))) ||
          new Set(statuses.map(p=>`${p.game_date||''}|${p.matchup}|${p.team}|${p.player}`)).size !== statuses.length ||
          ref.player_status_count !== statuses.length ||
          ref.player_status_issued_at !== ref.report_issued_at)
        throw Error('NBA-reported player rows did not pass verification');
      const codes=[...new Set(statuses.map(s=>s.team))].sort((a,b)=>fullName(a).localeCompare(fullName(b)));
      $('officialPlayerTeam').innerHTML='<option value="">All reporting teams</option>' + codes.map(code=>`<option value="${esc(code)}">${esc(fullName(code))}</option>`).join('');
      $('officialPlayerTeam').disabled=false;
      $('officialPlayerCount').textContent = statuses.length + ' reported player entries';
      $('officialPlayerWarning').textContent='Source: NBA-issued injury PDF at the time above. These are reported statuses, not final lineups; an unlisted player is not automatically available. No Elo adjustments are applied.';
      const draw = () => {
        const team=$('officialPlayerTeam').value;
        const rows=statuses.filter(s=>!team||s.team===team);
        $('officialPlayerRows').innerHTML= rows.length ? rows.slice(0,160).map(s=>
          `<div class="official-player"><div><strong>${esc(s.player)}</strong><span class="small"> ${esc(fullName(s.team))} · ${esc(s.matchup)}${s.game_date ? ' · '+esc(s.game_date):''}</span><div class="small">${esc(s.reason||'Reason not supplied')}</div></div><span class="pill">${esc(s.status)}</span></div>`
        ).join('') : '<p class="notice">No reported players in this filter. This does not establish full availability.</p>';
        if (rows.length>160) $('officialPlayerRows').insertAdjacentHTML('beforeend','<p class="small">Showing the first 160 entries; filter by team to see more.</p>');
      };
      $('officialPlayerTeam').onchange=draw;
      draw();
    } catch(_) {
      resetOfficial();
    } finally {
      clearTimeout(timeout);
    }
  }
  $('officialInjuryHelpLink').href = officialIndexFallback;
  $('liveRetry').addEventListener('click', () => { manualLoaded=false; load(); loadOfficialReport(); });
  load();
  loadOfficialReport();
})();
