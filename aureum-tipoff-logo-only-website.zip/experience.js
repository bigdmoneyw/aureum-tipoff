/* Aureum editorial experience — source-dependent scouting, comparison and what-if research.
   No synthetic team performance or player-impact estimates are represented as real. */
(() => {
  'use strict';
  const el = id => document.getElementById(id);
  // Route hashes are for page navigation. The keyboard skip link must focus
  // content without changing the active page or overwriting its route.
  document.querySelector('.skip-link')?.addEventListener('click', event => {
    event.preventDefault();
    const target = document.querySelector('.page.active h1, .page.active h2') || document.getElementById('site-main');
    if (!target) return;
    target.setAttribute('tabindex', '-1');
    target.focus({preventScroll:false});
  });

  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const registry = Array.isArray(teams) ? teams : [];
  const teamName = c => registry.find(t=>t[0]===c)?.[1] || c;
  const teamInfo = c => registry.find(t=>t[0]===c);
  const numbers = n => typeof n==='number' && Number.isFinite(n);
  const fixed = (n, digits=1) => numbers(n) ? n.toFixed(digits) : '—';
  const pct = n => numbers(n) ? (n*100).toFixed(1)+'%' : '—';
  let snapshot = window.AureumSnapshot || null;

  function options(selected) {
    return registry.map(t=>`<option value="${esc(t[0])}" ${t[0]===selected?'selected':''}>${esc(t[1])}</option>`).join('');
  }
  ['scoutTeam','gameAway','gameHome'].forEach(id => {
    const element=el(id); if (element) element.innerHTML=options(id==='gameHome'?'BOS':'GSW');
  });
  const currentTeam = () => el('scoutTeam').value;
  function ready() { return snapshot && snapshot.schema_version===2 && snapshot.season_pulse?.teams && snapshot.teams; }
  function season(code) { return ready() ? snapshot.season_pulse.teams[code] : null; }
  function rating(code) {
    const n=ready()?snapshot.teams[code]?.rating:null;
    return numbers(n)?n:null;
  }
  function metric(key, label, one, two, note, suffix='') {
    const a=one?.[key], b=two?.[key];
    const value = n => numbers(n) ? (key==='win_pct'?pct(n):`${n>0 && key==='point_diff'?'+':''}${fixed(n)}${suffix}`) : '—';
    const magnitude = numbers(a)&&numbers(b) ? Math.max(1,Math.abs(a),Math.abs(b)) : 1;
    const width = n => numbers(n)?Math.min(100,Math.abs(n)/magnitude*90+8):0;
    return `<div class="compare-metric"><div class="compare-metric-title">${esc(label)}<span class="small">${esc(note)}</span></div>
       <div class="compare-visual"><strong>${value(a)}</strong><div class="compare-bars"><div class="compare-bar compare-bar-a" style="width:${width(a)}%"></div><div class="compare-bar compare-bar-b" style="width:${width(b)}%"></div></div><strong>${value(b)}</strong></div></div>`;
  }
  function compareRender() {
    const a=el('compareA').value,b=el('compareB').value, container=el('compareData');
    if(a===b) {container.innerHTML='<div class="empty">Choose two different franchises to compare.</div>';return;}
    const sa=season(a),sb=season(b);
    const ra=rating(a),rb=rating(b);
    if(!sa||!sb){container.innerHTML=`<div class="compare-empty"><span class="eyebrow">Awaiting sourced records</span><h3>${esc(teamName(a))} <span class="muted">vs</span> ${esc(teamName(b))}</h3><p>Season scoring and team ratings require a current data snapshot. No figures are invented when the feed is missing.</p><button class="text-link" data-compare-to="live">View data status ↗</button></div>`;return;}
    const aPlayed=sa.wins+sa.losses,bPlayed=sb.wins+sb.losses;
    container.innerHTML=`<div class="compare-kick"><span class="eyebrow">${esc(snapshot.season_pulse.season)} / completed NBA regular-season results</span><span class="small">${esc(snapshot.source||'Research data')} · ${esc((snapshot.generated_at||'').slice(0,10))}</span></div>
      <div class="compare-scoreline"><div><div class="small">${esc(teamName(a))}</div><strong>${esc(sa.wins)}–${esc(sa.losses)}</strong><span class="small">${aPlayed} games recorded</span></div><span class="compare-vs">VERSUS</span><div><div class="small">${esc(teamName(b))}</div><strong>${esc(sb.wins)}–${esc(sb.losses)}</strong><span class="small">${bPlayed} games recorded</span></div></div>
      ${metric('win_pct','Win percentage',sa,sb,'Share of completed games won. This is not an official standing or tie-break ranking.','')}
      ${metric('ppg','Points scored / game',sa,sb,'Average points scored per completed game.')}
      ${metric('opp_ppg','Points allowed / game',sa,sb,'Average opponent points; lower is better.')}
      ${metric('point_diff','Scoring margin / game',sa,sb,'Average points scored minus allowed; summarizes outcomes, not style.')}
      <div class="compare-foot"><span><b>Historical Elo</b> ${ra===null?'—':Math.round(ra)} <span aria-hidden="true">/</span> ${rb===null?'—':Math.round(rb)}</span><span class="small">Elo includes earlier completed games. It does not measure current rosters or individual players.</span></div>
      <div class="compare-insight"><span class="eyebrow">Reading the matchup</span><p>${numbers(sa.point_diff)&&numbers(sb.point_diff)? (Math.abs(sa.point_diff-sb.point_diff)<1?'Their average scoring margins are similar so far; opponent strength and recent availability could still matter.': `${esc(teamName(sa.point_diff>sb.point_diff?a:b))} has the higher average scoring margin by ${fixed(Math.abs(sa.point_diff-sb.point_diff))} points per game. This describes results already played, not a guarantee for their next meeting.`):'The source has not provided sufficient scoring-margin data to compare the teams.'}</p></div>`;
  }
  function teamScout(code) {
    if(!registry.some(t=>t[0]===code)) return;
    el('scoutTeam').value=code;
    window.AureumSelectedTeam=code;
    el('scoutTitle').textContent=teamName(code);
    el('scoutSubtitle').textContent=`${teamInfo(code)?.[3]==='West'?'Western':'Eastern'} Conference · Scouting dossier`;
    el('scoutMonogram').textContent=code;
    const record=season(code),elo=rating(code);
    const root=el('scoutReadout');
    if(!record) {
      root.innerHTML=`<div class="scout-empty"><div><span class="eyebrow">Sourced intelligence / not yet loaded</span><h3>We won't guess at ${esc(teamName(code))}'s numbers.</h3><p>When a complete research snapshot is collected, this page will show the team's actual current-season record, scoring averages, recent form, and historical Elo, with explanations of each number.</p><button class="text-link" data-scout-to="live">View data source status ↗</button></div><span class="scout-ghost" aria-hidden="true">${esc(code)}</span></div>`;
      return;
    }
    const last=record.last_game;
    const recent=last ? `Last recorded game: ${esc(last.result||'—')} ${esc(last.scored)}–${esc(last.allowed)} ${last.place==='home'?'vs':'at'} ${esc(teamName(last.opponent))} · ${esc((last.date||'').slice(0,10))}` : 'No last-game result in the current snapshot.';
    root.innerHTML=`<div class="scout-metrics"><div class="scout-primary"><span class="eyebrow">Current season / completed results</span><div class="scout-record">${esc(record.wins)}<span>—</span>${esc(record.losses)}</div><p>Wins — losses</p><div class="scout-season">${esc(snapshot.season_pulse.season)} NBA regular season<br>${esc(record.wins+record.losses)} games recorded</div></div>
    <div class="scout-pace"><div><span class="small">Scored per game</span><strong>${fixed(record.ppg)}</strong><p>The average points scored in completed games. Not a pace-adjusted offensive rating.</p></div><div><span class="small">Allowed per game</span><strong>${fixed(record.opp_ppg)}</strong><p>The average points given up. Lower can indicate stronger score prevention, but pace matters.</p></div></div>
    <div class="scout-margin"><span class="small">Average scoring margin</span><strong>${numbers(record.point_diff)&&record.point_diff>0?'+':''}${fixed(record.point_diff)}</strong><p>Points scored minus points allowed per game. Positive means the team has outscored opponents on average.</p></div></div>
    <div class="scout-story"><div><span class="eyebrow">The short read</span><h3>${numbers(record.point_diff) ? (record.point_diff>0?'Outscoring the opposition.':record.point_diff<0?'Playing from a scoring deficit.':'Even on aggregate.'):'Scoring margin pending.'}</h3><p>${esc(recent)}</p><p><b>Last five:</b> ${esc(record.last_five||'—')} · <b>Current streak:</b> ${esc(record.streak||'—')}</p></div><div class="elo-orbit"><div class="small">Historical Elo</div><strong>${elo===null?'—':Math.round(elo)}</strong><p>Team-strength rating informed by recorded results across multiple seasons. Not an individual-player assessment.</p></div></div>
    <div class="source-line"><span>${esc(snapshot.source||'Research source')}</span><span>Snapshot: ${esc(snapshot.generated_at||'Unknown')}</span></div>`;
  }
  function resetSelect() {
    const chosen=window.AureumSelectedTeam;
    if(chosen && registry.some(t=>t[0]===chosen)) el('scoutTeam').value=chosen;
    teamScout(currentTeam());
  }
  el('scoutTeam').addEventListener('change',()=>teamScout(currentTeam()));
  el('scoutCompare').addEventListener('click',()=>{el('compareA').value=currentTeam();el('compareB').value=currentTeam()==='BOS'?'GSW':'BOS';el('compareA').dispatchEvent(new Event('change'));compareRender();location.hash='compare';});
  el('scoutGame').addEventListener('click',()=>{el('gameAway').value=currentTeam();el('gameHome').value=currentTeam()==='BOS'?'GSW':'BOS';gameDraw();location.hash='gameroom';});
  window.addEventListener('aureum:select-team',e=>{if(e.detail?.team) teamScout(e.detail.team);});
  function gameDraw() {
    const a=el('gameAway').value,h=el('gameHome').value,out=el('gameSensitivityResult');
    if(a===h) {out.innerHTML='<div class="empty">Select different home and away franchises.</div>';return;}
    const ar=rating(a),hr=rating(h),m=snapshot?.model?.settings||{};
    const scale=m.logistic_scale,edge=m.home_advantage;
    if(!numbers(ar)||!numbers(hr)||!numbers(scale)||scale<=0||!numbers(edge)){
      out.innerHTML='<div class="empty">This what-if explorer needs sourced team ratings and documented model settings. No probability will be invented.</div>';return;
    }
    const aLoss=Number(el('gameAwayAvailability').value)||0,hLoss=Number(el('gameHomeAvailability').value)||0;
    const base=1/(1+Math.pow(10,-(hr-ar+edge)/scale));
    const adjusted=1/(1+Math.pow(10,-((hr-hLoss)-(ar-aLoss)+edge)/scale));
    const homePercent=adjusted*100;
    const delta=(adjusted-base)*100;
    out.innerHTML=`<div class="game-calculation"><div class="eyebrow">Hypothetical team-rating scenario</div><div class="game-prob-row"><div><span>${esc(teamName(a))} / away</span><strong>${fixed((1-adjusted)*100)}%</strong></div><span class="versus">VS</span><div><span>${esc(teamName(h))} / home</span><strong>${fixed(homePercent)}%</strong></div></div><div class="bar" role="img" aria-label="Scenario home probability ${fixed(homePercent)} percent"><div style="width:${Math.max(0,Math.min(100,homePercent))}%"></div></div><div class="game-factors"><span>Baseline home chance <b>${fixed(base*100)}%</b></span><span>Assumed change <b>${delta>0?'+':''}${fixed(delta)} points</b></span></div><p>The home team starts ${esc(Math.round(hr-ar+edge))} Elo points above the away team after the model's home-court adjustment. Your selected hypothetical setbacks change the assumed team-rating gap by ${esc(aLoss-hLoss)} Elo points. That moves the home-side scenario by ${delta>0?'+':''}${fixed(delta)} percentage points.</p><p class="small"><strong>These are not measured player effects.</strong> The chosen -40 and -90 Elo settings are illustrative assumptions, not estimates tied to named NBA players or injuries.</p></div>`;
  }
  ['gameAway','gameHome','gameAwayAvailability','gameHomeAvailability'].forEach(id=>el(id).addEventListener('change',gameDraw));
  el('gameSwap').addEventListener('click',()=>{const a=el('gameAway').value;el('gameAway').value=el('gameHome').value;el('gameHome').value=a;gameDraw();});
  function gameForecasts() {
    const parent=el('gameForecastList');
    const list=(snapshot?.forecasts||[]).filter(x=>x&&numbers(x.home_probability)&&x.home_probability>=0&&x.home_probability<=1&&x.tipoff&&x.first_recorded_at&&Number.isFinite(Date.parse(x.first_recorded_at))&&Date.parse(x.first_recorded_at)<Date.parse(x.tipoff)&&Date.parse(x.tipoff)>Date.now()).slice(0,12);
    if(!list.length){parent.innerHTML='<div class="empty">There are no upcoming timestamped forecasts in the current data snapshot. Schedules and percentages will appear only after a validated provider update.</div>';return;}
    parent.innerHTML=list.map(g=>`<article class="game-forecast"><div class="game-forecast-date">${esc(new Date(g.tipoff).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}))}<span>Recorded ${esc(new Date(g.first_recorded_at).toLocaleString('en-US',{timeZone:'UTC',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}))} UTC</span></div><div class="game-forecast-teams"><strong>${esc(teamName(g.away))}</strong><span>at</span><strong>${esc(teamName(g.home))}</strong></div><div class="game-forecast-chance"><strong>${fixed(g.home_probability*100)}%</strong><span>Modeled home win chance · Elo only</span></div><p>Based on historical team ratings and modeled home-court advantage. This archived forecast does not account for verified player availability.</p></article>`).join('');
  }
  el('compareA').addEventListener('change',compareRender);
  el('compareB').addEventListener('change',compareRender);
  document.addEventListener('click',e=>{
    const forward=e.target.closest('[data-compare-to],[data-scout-to]');
    if(forward) location.hash=forward.dataset.compareTo||forward.dataset.scoutTo;
  });
  function refresh() {
    compareRender();resetSelect();gameDraw();gameForecasts();
    const status=el('homeDataStatus');
    if(status)status.textContent=ready()?`Research snapshot: ${snapshot.season} · updated ${(snapshot.generated_at||'').slice(0,10)} · source: ${snapshot.source||'third party'}`:'Verified data appears when a sourced research snapshot is available';
  }
  window.addEventListener('aureum:data-ready',event=>{snapshot=event.detail?.snapshot||null;refresh();});
  window.addEventListener('aureum:data-unavailable',()=>{snapshot=null;refresh();});
  window.addEventListener('hashchange',()=>{if(location.hash==='#scout')resetSelect();});
  refresh();
})();
