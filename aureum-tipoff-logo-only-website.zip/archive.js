/* Aureum Tipoff's historical season RESEARCH — not a live score feed. */
(()=>{
  'use strict';
  const dataset=window.AureumHistoricalArchive;
  const lookup=Array.isArray(window.teams)?window.teams:(typeof teams!=='undefined'?teams:[]);
  const byId=id=>document.getElementById(id);
  if(!dataset||!byId('archive')||!Array.isArray(lookup)||lookup.length!==30)return;
  const seasonYears=['2024-25','2025-26'];
  const labels={
    'WinPct':{name:'Win percentage',unit:'pct',better:1,desc:'Share of 82 regular-season games won. It summarizes results, not opponent strength or postseason performance.'},
    'NetRtg':{name:'Net rating',unit:'rating',better:1,desc:'Point differential per 100 estimated possessions. Positive values mean the team outscored opponents after accounting for pace.'},
    'ORtg':{name:'Offensive rating',unit:'rating',better:1,desc:'Estimated points scored per 100 possessions. Higher usually means more efficient scoring.'},
    'DRtg':{name:'Defensive rating',unit:'rating',better:-1,desc:'Estimated points allowed per 100 possessions. Lower is better defensively.'},
    'eFG':{name:'Effective field goal percentage',unit:'pct',better:1,desc:'Field-goal accuracy adjusted for three-pointers being worth more than two-pointers. It does not include free throws.'},
    'TS':{name:'True shooting percentage',unit:'pct',better:1,desc:'Scoring efficiency including free throws and the additional value of three-pointers.'},
    'TOV_pct':{name:'Turnover percentage',unit:'percent_points',better:-1,desc:'Estimated share of possessions ending in a turnover. Lower is generally better, though different sources define possessions differently.'},
    'ORB_pct':{name:'Offensive rebound percentage',unit:'percent_points',better:1,desc:'Share of available offensive rebounds secured. Higher means more second-chance opportunities.'},
    'Pace':{name:'Pace',unit:'rating',better:0,desc:'Estimated possessions per 48 minutes. Higher means faster play, not necessarily better basketball.'}
  };
  const safe=txt=>String(txt).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const finite=n=>typeof n==='number'&&Number.isFinite(n);
  const fmt=(number,metric)=>{
    if(!finite(number))return '—';
    const unit=labels[metric].unit;
    return unit==='pct'?(number*100).toFixed(1)+'%':unit==='percent_points'?number.toFixed(1)+'%':number.toFixed(1);
  };
  const fmtChange=(number,metric)=>{
    if(!finite(number))return '—';
    const value=labels[metric].unit==='pct'?number*100:number;
    return (value>0?'+':'')+value.toFixed(1)+(labels[metric].unit==='pct'?' pp':'');
  };
  const difference=(a,b,metric)=>a&&b&&finite(a[metric])&&finite(b[metric])?b[metric]-a[metric]:null;
  const codeName=Object.fromEntries(lookup.map(t=>[t[0],t[1]]));
  const root=byId('archiveResults');
  const detail=byId('archiveDetail');
  let selected='OKC';
  const seasonSelect=byId('archiveSeason');
  const metricSelect=byId('archiveMetric');
  const search=byId('archiveSearch');
  metricSelect.innerHTML=Object.entries(labels).map(([key,item])=>`<option value="${safe(key)}">${safe(item.name)}</option>`).join('');
  metricSelect.value='NetRtg';
  function rows(){
    const metric=metricSelect.value,year=seasonSelect.value;
    const names=lookup.filter(t=>t[1].toLowerCase().includes(search.value.trim().toLowerCase())||t[0].toLowerCase().includes(search.value.trim().toLowerCase()));
    const data=names.map(t=>{
      const first=dataset.seasons[seasonYears[0]]?.[t[0]],second=dataset.seasons[seasonYears[1]]?.[t[0]];
      const item=year==='delta'?difference(first,second,metric):(dataset.seasons[year]?.[t[0]]?.[metric]);
      return {code:t[0],name:t[1],value:item,first,second};
    });
    const direction=year==='delta'?1:labels[metric].better||1;
    data.sort((a,b)=>direction*((b.value??-1e6)-(a.value??-1e6))||a.name.localeCompare(b.name));
    return data;
  }
  function renderDetail(){
    const code=selected,first=dataset.seasons[seasonYears[0]]?.[code],second=dataset.seasons[seasonYears[1]]?.[code],metric=metricSelect.value;
    if(!first||!second){detail.innerHTML='<div class="archive-empty">The historical archive does not contain this team.</div>';return;}
    const older=first[metric],newer=second[metric],delta=difference(first,second,metric);
    const deltaGood=labels[metric].better===0?'A different tempo is not automatically an improvement.':delta*labels[metric].better>0?'The metric moved in the generally favorable direction.':delta*labels[metric].better<0?'The metric moved in the generally unfavorable direction.':'The metric was unchanged.';
    const winChange=second.W-first.W;
    detail.innerHTML=`<div class="archive-feature-stat"><span class="archive-season-pill">2024–25 → 2025–26</span><h4>${safe(codeName[code]||code)}</h4><strong>${fmt(newer,metric)}</strong><span>${safe(labels[metric].name)} in 2025–26</span><div class="archive-track"><div style="width:${Math.max(3,Math.min(100,100*Math.abs(newer)/(metric==='WinPct'||metric==='eFG'||metric==='TS'?1:metric==='TOV_pct'||metric==='ORB_pct'?40:metric==='Pace'||metric==='ORtg'||metric==='DRtg'?140:25)))}%"></div></div><span>Previous season: ${fmt(older,metric)} · Change: ${fmtChange(delta,metric)}</span></div>
      <div class="archive-feature-explain"><span class="eyebrow">One team, two completed seasons</span><h3>${safe(labels[metric].name)}: what changed?</h3><p>${safe(labels[metric].desc)}</p><p><strong>${safe(codeName[code]||code)}</strong> went from ${first.W}–${first.L} to ${second.W}–${second.L}: ${winChange>0?'+':''}${winChange} wins between these seasons. ${safe(deltaGood)}</p><p class="small">These are team-level season summaries. They do not show game-to-game changes, roster availability, or a measured effect of any specific player.</p><button class="text-link" type="button" id="archiveScout">Open franchise profile ↗</button></div>`;
    byId('archiveScout').addEventListener('click',()=>{
      window.AureumSelectedTeam=code;
      location.hash='scout';
      window.dispatchEvent(new CustomEvent('aureum:select-team',{detail:{team:code}}));
    });
  }
  function renderTable(){
    const year=seasonSelect.value,metric=metricSelect.value,items=rows();
    const vals=items.map(item=>item.value).filter(finite);
    const lo=vals.length?Math.min(...vals):0,hi=vals.length?Math.max(...vals):1;
    const showDelta=year==='delta';
    root.innerHTML=items.length?`<div class="archive-table-scroller"><table class="archive-table"><caption class="sr-only">Team-level historical ${safe(labels[metric].name)} ranked for ${safe(year==='delta'?'season-over-season change':year)}</caption><thead><tr><th scope="col">Team</th><th scope="col">${showDelta?'2024–25':'Wins–losses'}</th><th scope="col">${showDelta?'2025–26':'Selected metric'}</th><th scope="col">${showDelta?'Change':'Relative position'}</th></tr></thead><tbody>${items.map((it,index)=>{
        const last=dataset.seasons[showDelta?seasonYears[1]:year]?.[it.code];
        const pct=hi===lo?50:Math.max(5,Math.round(100*(it.value-lo)/(hi-lo)));
        const sign=(it.value>0?'archive-up':it.value<0?'archive-down':'archive-flat');
        return `<tr><td><button type="button" class="archive-team" data-archive-team="${safe(it.code)}">${index+1}. ${safe(it.name)}</button></td><td data-label="${showDelta?'2024–25':'Record'}">${showDelta?fmt(it.first[metric],metric):`${last.W}–${last.L}`}</td><td data-label="${showDelta?'2025–26':labels[metric].name}">${showDelta?fmt(it.second[metric],metric):fmt(it.value,metric)}</td><td data-label="${showDelta?'Change':'Relative position'}">${showDelta?`<span class="archive-delta ${sign}">${fmtChange(it.value,metric)}</span>`:`<div class="archive-bar" role="img" aria-label="Relative position: ${pct} percent of the displayed range"><div style="width:${pct}%"></div></div>`}</td></tr>`;
      }).join('')}</tbody></table></div>`:'<div class="archive-empty">No franchises match that search.</div>';
    root.querySelectorAll('[data-archive-team]').forEach(button=>button.addEventListener('click',()=>{
      selected=button.dataset.archiveTeam;
      renderDetail();
      detail.scrollIntoView({block:'nearest',behavior:'smooth'});
    }));
    byId('archiveSummary').textContent=`${items.length} of 30 teams · ${showDelta?'2025–26 minus 2024–25':year} · ${labels[metric].name}`;
  }
  function refresh(){renderTable();renderDetail();}
  seasonSelect.addEventListener('change',refresh);
  metricSelect.addEventListener('change',refresh);
  search.addEventListener('input',renderTable);
  refresh();
})();
