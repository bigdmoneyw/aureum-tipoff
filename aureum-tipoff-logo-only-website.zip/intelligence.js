/* Evidence-first factor atlas, season scenario and team-logo-only matchup panels.
   No hidden live-data assumptions or sports-betting functionality. */
(()=>{'use strict';
const el=id=>document.getElementById(id), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const roster=typeof teams!=='undefined'&&Array.isArray(teams)?teams:[];
const teamName=code=>roster.find(x=>x[0]===code)?.[1]||code;
const atlas=Array.isArray(window.AureumFactorAtlas)?window.AureumFactorAtlas:[];
const categories=['All',...new Set(atlas.map(x=>x.group))];
const selectors=roster.map(x=>`<option value="${esc(x[0])}">${esc(x[1])}</option>`).join('');
let snapshot=window.AureumSnapshot||null;
const accepted=()=>snapshot&&snapshot.schema_version===2&&snapshot.data_quality?.complete_history_verified===true&&snapshot.season_pulse?.teams&&snapshot.teams&&snapshot.model?.settings;
const status=(key)=>{if(!accepted())return 'Source not accepted';return ['Win-loss record','Scoring margin','Last-five form','Elo team rating'].includes(key)?'Results snapshot available':'Requires additional verified input'};

const section=document.createElement('section');section.className='page';section.id='intelligence';section.setAttribute('aria-labelledby','intelTitle');
section.innerHTML=`<div class="intelligence-hero"><div class="wrap intel-hero-layout"><div><span class="eyebrow">Aureum / Intelligence Studio</span><h2 id="intelTitle">Explore the game.<br><em>Question every edge.</em></h2><p>Go beyond a single matchup. Explore 80 separately explained components, see what the model truly measures, and test how a sourced season record might evolve.</p><div class="actions"><a href="#intelligence" class="btn" id="intelExplore">Explore the factor atlas ↓</a><button class="btn secondary" id="intelJumpSeason">Season scenario ↓</button></div></div><img src="assets/intelligence-court.svg" width="860" height="720" alt="Original gold basketball court and analytics arcs" loading="lazy"></div></div>
<div class="wrap intelligence-content"><section class="intel-telling" aria-label="Approach to evidence"><div><span class="eyebrow">What makes a useful model?</span><h3>More signals.<br><em>Fewer unsupported claims.</em></h3></div><p>Some components describe results. Others require possession-level feeds, roster verification, or new predictive modeling. The glossary is comprehensive, but <strong>a listed factor is not automatically an active model input</strong>. We only calculate what our source evidence actually supports.</p></section>
<section class="intel-star-story" aria-label="Franchise identity and player context"><img src="assets/player-impact.svg" alt="Original illustration of player movement, shooting zones and player impact" width="760" height="480" loading="lazy"><div><span class="eyebrow">Franchise identity</span><h3>Thirty teams.<br>Every matchup.</h3><p>Compare teams by franchise, without speculative player portraits or outdated starting-five graphics. A team logo identifies the franchise; it does not imply that particular players are healthy, starting, or available.</p><button class="text-link" id="intelOpenGame">Explore team matchups ↗</button></div></section>
<section class="factor-atlas" id="factorAtlas" aria-labelledby="factorHeading"><span class="eyebrow">Factor Atlas / 80 separately explained components</span><h3 id="factorHeading">An entire vocabulary of basketball.</h3><p class="intel-sub">Each entry includes a definition, calculation or measurement, basketball meaning, limitation, availability status, and a source for the metric terminology. A definition source is not evidence that a factor improves win predictions.</p><div class="factor-tools"><label class="control">Find a factor<input type="search" id="factorFind" placeholder="Try turnover, rest, three-point, Brier..." autocomplete="off"></label><label class="control">Category<select id="factorCategory">${categories.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label></div><div class="intel-count" id="factorCount" role="status" aria-live="polite"></div><div class="factor-accordion" id="factorRows"></div></section>
<section class="intel-season" id="seasonScenario" aria-labelledby="seasonHeading"><div class="intel-season-head"><div><span class="eyebrow">Season Studio / transparent simulation</span><h3 id="seasonHeading">What could the finish look like?</h3><p>When real results and historical Elo are verified, simulate the remaining regular-season games against a <strong>hypothetical neutral-strength opponent</strong>. The displayed range is conditional on those simplifying assumptions, not a schedule-aware forecast.</p></div><img src="assets/season-journey.svg" width="560" height="440" alt="Original illustration of an 82-game season journey" loading="lazy"></div>
<div class="season-controls"><label class="control">Team<select id="seasonTeam">${selectors}</select></label><label class="control">Assumed team-strength change (<output id="seasonChangeValue">0 Elo</output>)<input id="seasonChange" type="range" min="-100" max="100" step="10" value="0"></label><button class="btn" id="seasonRun" type="button">Run 4,000 scenarios</button></div>
<div class="season-readout" id="seasonResult" role="status" aria-live="polite"><p>Awaiting a verified current-season NBA results snapshot and fitted historical Elo settings. No record will be invented.</p></div><div class="season-league" id="seasonLeague" aria-live="polite"><h4>League-wide neutral-opponent study</h4><div class="tablewrap" id="seasonLeagueTable"><p>Available after all thirty teams have accepted results.</p></div></div><div class="season-meaning"><h4>What changes a real season projection?</h4><p>A genuine schedule-based model would simulate the actual remaining opponents and venues, verify expected lineups, account for uncertainty and compare its forecasts against outcomes. This neutral-opponent study does not use an upcoming schedule, injury-adjusted ratings, playoff seeding or NBA tie-break rules.</p></div></section>
<section class="intel-guardrail"><span class="eyebrow">How to read all outputs</span><div><h3>Four layers of truth.</h3><ol><li><b>Observed:</b> wins, scores and other sourced facts.</li><li><b>Calculated:</b> derived averages or ratings, with formulas.</li><li><b>Estimated:</b> fitted statistical quantities and uncertainty.</li><li><b>Hypothetical:</b> user-selected changes and illustrative scenarios.</li></ol></div></section></div>`;
document.querySelector('main').append(section);
const nav=document.querySelector('.nav'); if(nav&&!nav.querySelector('[data-page="intelligence"]')){const btn=document.createElement('button');btn.type='button';btn.dataset.page='intelligence';btn.textContent='Intelligence';nav.insertBefore(btn,[...nav.children].find(x=>x.dataset.page==='about')||null);btn.addEventListener('click',()=>{page('intelligence');location.hash='intelligence'})}
if(location.hash==='#intelligence'&&typeof page==='function')page('intelligence');
// Unobtrusive discovery link added to an existing homepage story, not a replacement for the design.
const home=document.querySelector('#home .final-note');if(home&&!home.querySelector('.intel-home-entry')){const button=document.createElement('button');button.type='button';button.className='text-link intel-home-entry';button.textContent='Explore all 80 model factors ↗';button.addEventListener('click',()=>{page('intelligence');location.hash='intelligence'});home.querySelector('div:last-child')?.appendChild(button)}
el('intelJumpSeason').addEventListener('click',()=>el('seasonScenario').scrollIntoView({behavior:'smooth'}));
el('intelExplore').addEventListener('click',e=>{e.preventDefault();el('factorAtlas').scrollIntoView({behavior:'smooth'})});
el('intelOpenGame').addEventListener('click',()=>{page('gameroom');location.hash='gameroom'});
function drawFactors(){const q=el('factorFind').value.trim().toLowerCase(),cat=el('factorCategory').value;
 const rows=atlas.filter(x=>(cat==='All'||x.group===cat)&&[x.title,x.group,x.definition,x.why].some(v=>v.toLowerCase().includes(q)));
 el('factorCount').textContent=`${rows.length} of ${atlas.length} components. Listing them does not mean they have fitted prediction coefficients.`;
 el('factorRows').innerHTML=rows.length?rows.map((x,i)=>`<details class="intel-factor"><summary><span class="factor-index">${String(i+1).padStart(2,'0')}</span><span class="factor-title">${esc(x.title)}<small>${esc(x.group)}</small></span><span class="factor-chevron" aria-hidden="true">＋</span></summary><div class="factor-description"><p><b>What it means</b>${esc(x.definition)}</p><p><b>Measurement</b>${esc(x.measurement)}</p><p><b>Why it matters</b>${esc(x.why)}</p><p><b>Limitations</b>${esc(x.caution)}</p><p><b>In Aureum today</b>${esc(status(x.title))}</p><p class="factor-source"><a href="${esc(x.reference)}" target="_blank" rel="noopener noreferrer">Read reference ↗</a><span>${esc(x.reference_type)}</span></p></div></details>`).join(''):'<p class="notice">No matching factors. Try another term.</p>';
}
el('factorFind').addEventListener('input',drawFactors);el('factorCategory').addEventListener('change',drawFactors);
function drawSeason(){const target=el('seasonResult');const code=el('seasonTeam').value;
 const modifier=Number(el('seasonChange').value);el('seasonChangeValue').textContent=(modifier>0?'+':'')+modifier+' Elo';
 if(!accepted()) {target.innerHTML='<p class="intel-await">No accepted NBA research snapshot. Season outcomes cannot be produced from invented records.</p>';el('seasonLeagueTable').innerHTML='<p class="intel-await">League-wide projections require accepted current-season data for all 30 franchises.</p>';return}
 const rec=snapshot.season_pulse.teams[code],rating=snapshot.teams[code]?.rating;
 const result=window.AureumProjection?.project(rec,rating,snapshot.model.settings,{modifier,seed:20261117+roster.findIndex(t=>t[0]===code)});
 if(!result){target.innerHTML='<p class="intel-await">Team data or model parameters failed validation. This scenario is unavailable.</p>';return}
 target.innerHTML=`<span class="eyebrow">Research scenario / ${esc(snapshot.season_pulse.season)}</span><h4>${esc(teamName(code))}</h4><div class="season-numbers"><div><small>Observed record</small><strong>${result.observedWins}–${result.observedLosses}</strong></div><div><small>Mean final wins · hypothetical</small><strong>${result.estimatedWins.toFixed(1)}</strong></div><div><small>Central 80% simulation span</small><strong>${result.p10}–${result.p90}</strong></div><div><small>Games remaining</small><strong>${result.remaining}</strong></div></div><p>The model uses sourced historical Elo, a neutral 1,500-rated opponent and your explicitly selected <b>${modifier>0?'+':''}${modifier} Elo</b> hypothetical change. It ran ${result.runs.toLocaleString()} independent simulated seasons. No verified future schedule, player availability, or calibrated season-level forecast is implied.</p>`;
 const full=roster.map(t=>{const r=snapshot.season_pulse.teams[t[0]],elo=snapshot.teams[t[0]]?.rating;const projection=window.AureumProjection?.project(r,elo,snapshot.model.settings,{runs:1000,seed:20261117+roster.findIndex(y=>y[0]===t[0])});return projection?{name:t[1],...projection}:null});
 if(full.every(Boolean)){full.sort((a,b)=>b.estimatedWins-a.estimatedWins);el('seasonLeagueTable').innerHTML=`<table><caption>Illustrative neutral-opponent season scenarios; not NBA standings, seeding, or schedule-aware forecasts.</caption><thead><tr><th>Team</th><th>Current W–L</th><th>Mean final wins</th><th>80% illustrative span</th></tr></thead><tbody>${full.map(x=>`<tr><td>${esc(x.name)}</td><td>${x.observedWins}–${x.observedLosses}</td><td>${x.estimatedWins.toFixed(1)}</td><td>${x.p10}–${x.p90}</td></tr>`).join('')}</tbody></table>`}
 else{el('seasonLeagueTable').innerHTML='<p>League-wide study unavailable: accepted records and ratings are incomplete.</p>'}
}
el('seasonChange').addEventListener('input',()=>{el('seasonChangeValue').textContent=(+el('seasonChange').value>0?'+':'')+el('seasonChange').value+' Elo'});
el('seasonTeam').addEventListener('change',drawSeason);el('seasonRun').addEventListener('click',drawSeason);
window.addEventListener('aureum:data-ready',e=>{snapshot=e.detail?.snapshot||null;drawFactors();drawSeason();drawTeamLogos()});
window.addEventListener('aureum:data-unavailable',()=>{snapshot=null;drawFactors();drawSeason();drawTeamLogos()});

// Every visible numeric team comparison is calculated from accepted source records.
const matchupBox=document.createElement('section');matchupBox.className='intel-matchup-audit';matchupBox.innerHTML='<span class="eyebrow">Matchup evidence / verified inputs only</span><h3>Which differences are measurable?</h3><p class="notice">Five existing features can be compared when a validated research snapshot exists. No untrained factor receives a fabricated weight.</p><div id="intelMatchupStats" aria-live="polite"><p class="notice">Awaiting sourced results.</p></div><button type="button" class="text-link" id="intelMatchupFactors">Learn about the remaining 80 factors ↗</button>';
const matchup=document.querySelector('#matchups .wrap.section');if(matchup)matchup.append(matchupBox);
function drawMatchupStats(){if(!accepted()){el('intelMatchupStats').innerHTML='<p class="notice">No accepted results snapshot; this section cannot calculate evidence.</p>';return}
 const a=el('teamA').value,b=el('teamB').value;if(a===b){el('intelMatchupStats').textContent='Choose two different teams.';return}
 const x=snapshot.season_pulse.teams[a],y=snapshot.season_pulse.teams[b],ra=snapshot.teams[a]?.rating,rb=snapshot.teams[b]?.rating;
 if(!x||!y){el('intelMatchupStats').textContent='Missing records for this matchup.';return}
 const rows=[['Observed W–L',`${x.wins}–${x.losses}`,`${y.wins}–${y.losses}`,'Historical outcomes, not a directly fitted win-probability feature'],['Scoring margin',x.point_diff,y.point_diff,'Points per game scored minus allowed'],['Points for / game',x.ppg,y.ppg,'Not pace adjusted'],['Points allowed / game',x.opp_ppg,y.opp_ppg,'Lower is generally better; not possession adjusted'],['Historical Elo',ra,rb,'The only directly fitted team strength feature in the Elo matchup study']];
 el('intelMatchupStats').innerHTML=`<div class="tablewrap"><table><caption>Accepted results snapshot: ${esc(snapshot.season_pulse.season)}. Figures are descriptive, except the documented Elo-based matchup study.</caption><thead><tr><th>Factor</th><th>${esc(teamName(a))}</th><th>${esc(teamName(b))}</th><th>Interpretation</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r[0])}</td><td>${esc(typeof r[1]==='number'?r[1].toFixed(1):r[1]??'Unavailable')}</td><td>${esc(typeof r[2]==='number'?r[2].toFixed(1):r[2]??'Unavailable')}</td><td>${esc(r[3])}</td></tr>`).join('')}</tbody></table></div>`;
}
el('intelMatchupFactors')?.addEventListener('click',()=>{page('intelligence');location.hash='intelligence'});
['teamA','teamB'].forEach(id=>el(id)?.addEventListener('change',drawMatchupStats));
window.addEventListener('aureum:data-ready',drawMatchupStats);
window.addEventListener('aureum:data-unavailable',drawMatchupStats);

// All 30 team identities are mapped to NBA franchise IDs. The matchup interface
// intentionally uses NO player portraits, fabricated lineups or image-generated logos.
// Logos are trademarks of their respective owners; source availability is NOT
// permission to republish. An appropriate usage review is required before launch.
const logoIds=window.AureumTeamSelectMedia?.logo_ids||{};
const teamPalette={
 ATL:['#C8102E','#FDB927'],BOS:['#007A33','#BA9653'],BKN:['#111111','#FFFFFF'],CHA:['#1D1160','#00788C'],
 CHI:['#CE1141','#111111'],CLE:['#860038','#FDBB30'],DAL:['#00538C','#B8C4CA'],DEN:['#0E2240','#FEC524'],
 DET:['#C8102E','#1D42BA'],GSW:['#1D428A','#FFC72C'],HOU:['#CE1141','#000000'],IND:['#002D62','#FDBB30'],
 LAC:['#C8102E','#1D428A'],LAL:['#552583','#FDB927'],MEM:['#5D76A9','#12173F'],MIA:['#98002E','#F9A01B'],
 MIL:['#00471B','#EEE1C6'],MIN:['#0C2340','#236192'],NOP:['#0C2340','#C8102E'],NYK:['#006BB6','#F58426'],
 OKC:['#007AC1','#EF3B24'],ORL:['#0077C0','#C4CED4'],PHI:['#006BB6','#ED174C'],PHX:['#1D1160','#E56020'],
 POR:['#E03A3E','#000000'],SAC:['#5A2D81','#63727A'],SAS:['#C4CED4','#000000'],TOR:['#CE1141','#000000'],
 UTA:['#000000','#F9A01B'],WAS:['#002B5C','#E31837']
};
function logoSources(code){
 const id=logoIds[code];
 if(!id)return [];
 // Local assets take precedence so a complete, licensed installation works offline.
 // Remote variants are fallback candidates for networked previews.
 return [`assets/logos/${code}.svg`,`assets/logos/${code}.png`,
  `https://cdn.nba.com/logos/nba/${id}/global/L/logo.svg`,
  `https://cdn.nba.com/logos/nba/${id}/primary/L/logo.png`,
  `https://cdn.nba.com/logos/nba/${id}/primary/L/logo.svg`];
}
function matchupTeamPanel(code,side){
 const colors=teamPalette[code]||['#173450','#e2b770'];
 const logo=logoIds[code]?`<img class="arena-team-logo" data-team-logo="${esc(code)}" alt="${esc(teamName(code))} logo" loading="eager" decoding="async">`:'';
 return `<article class="arena-team-panel logo-only-panel" data-team="${esc(code)}" data-side="${esc(side)}" data-logo-state="loading" style="--team-primary:${colors[0]};--team-secondary:${colors[1]}" aria-label="${esc(side)}: ${esc(teamName(code))}">
  <div class="arena-identity logo-only-identity">
    <div class="arena-team-emblem logo-only-emblem">${logo}<span class="arena-logo-fallback" aria-hidden="true">${esc(code)}</span></div>
    <div class="arena-light-ring" aria-hidden="true"></div>
  </div>
  <div class="arena-team-footer"><span class="arena-side">${esc(side)}</span><strong>${esc(teamName(code))}</strong></div>
 </article>`;
}
function loadLogos(node){
 const imgs=[...node.querySelectorAll('[data-team-logo]')];
 for(const img of imgs){
   const code=img.dataset.teamLogo;
   const panel=img.closest('.arena-team-panel');
   const holder=img.parentElement;
   const sources=logoSources(code);
   let index=0;
   const fail=()=>{
     img.hidden=true;
     panel.dataset.logoState='unavailable';
     holder.classList.add('logo-missing');
     updateLogoStatus(node);
   };
   const next=()=>{
     if(index>=sources.length){fail();return;}
     img.src=sources[index++];
   };
   img.addEventListener('error',next);
   img.addEventListener('load',()=>{
     if(!img.naturalWidth||!img.naturalHeight){next();return;}
     img.hidden=false;
     holder.classList.add('logo-loaded');
     holder.classList.remove('logo-missing');
     panel.dataset.logoState='loaded';
     updateLogoStatus(node);
   });
   next();
 }
 updateLogoStatus(node);
}
function updateLogoStatus(node){
 const panels=[...node.querySelectorAll('.arena-team-panel')];
 const loaded=panels.filter(p=>p.dataset.logoState==='loaded').length;
 const loading=panels.some(p=>p.dataset.logoState==='loading');
 const status=node.querySelector('.arena-media-status');
 if(!status)return;
 if(loading)status.textContent=`${loaded}/2 logos loaded · retrieving remaining logo…`;
 else if(loaded===2)status.textContent='2/2 team logos loaded';
 else status.textContent=`${loaded}/2 logos loaded · team abbreviations shown if images are unavailable`;
}
function drawTeamLogos(){
 for(const [anchor,a,b] of [['#matchups .two','teamA','teamB'],['#gameroom .sensitivity','gameAway','gameHome']]){
  const area=document.querySelector(anchor);if(!area)continue;
  const container=area.parentElement;
  let node=container?.querySelector('.star-lineup[data-for="'+a+'"]');
  if(!node){node=document.createElement('section');node.className='star-lineup star-lineup-arena logo-only-lineup';node.dataset.for=a;container.insertBefore(node,area)}
  const away=el(a)?.value||'GSW',home=el(b)?.value||'LAL';
  node.innerHTML=`<div class="arena-titlebar"><span>2026–27 • Head-to-head team select</span><span>Franchise identity · 30 NBA teams</span></div>
   <div class="arena-stage">${matchupTeamPanel(away,'Away')}<div class="arena-versus" aria-hidden="true"><span>VS</span><small>MATCHUP</small></div>${matchupTeamPanel(home,'Home')}</div>
   <div class="arena-disclosure"><span>Authentic NBA team marks, not AI player images or invented starting lineups. Team logos are trademarks of their respective owners; Aureum Tipoff is independent and not endorsed by the NBA.</span><span class="arena-media-status" role="status" aria-live="polite">Retrieving team logos…</span></div>`;
  loadLogos(node);
 }
}
['teamA','teamB','gameAway','gameHome'].forEach(id=>el(id)?.addEventListener('change',drawTeamLogos));
el('gameSwap')?.addEventListener('click',()=>queueMicrotask(drawTeamLogos));
drawFactors();drawSeason();drawTeamLogos();drawMatchupStats();
})();
