/* Aureum Tipoff: independent, data-free editorial interactions. */
(() => {
  'use strict';
  const copy = {
    clarity: ['Make the complex understandable.', 'A percentage matters only when you understand what it describes. We translate technical measures into useful basketball context, without pretending every number tells the whole story.'],
    evidence: ['Show where every number comes from.', 'Results, schedules and player status need a traceable source and timestamp. Research samples and hypothetical inputs are labeled separately from independently verified NBA records.'],
    honesty: ['A prediction is a testable claim, not a promise.', 'We keep uncertainty visible. We will not advertise measured forecast accuracy or player-level injury effects until authentic source data and independently auditable evaluations support them.']
  };
  const tabs = [...document.querySelectorAll('[data-mission]')];
  const panel = document.getElementById('missionPanel');
  if (!panel || !tabs.length) return;
  tabs.forEach(tab => tab.addEventListener('click', () => {
    const content = copy[tab.dataset.mission];
    if (!content) return;
    tabs.forEach(t => t.setAttribute('aria-pressed', String(t === tab)));
    panel.replaceChildren();
    const heading = document.createElement('h3'); heading.textContent=content[0];
    const paragraph = document.createElement('p'); paragraph.textContent=content[1];
    panel.append(heading, paragraph);
  }));
})();
