/* Pure season scenario engine. No schedule, injuries or unmeasured features are invented. */
(function(root){
'use strict';
const finite=x=>typeof x==='number'&&Number.isFinite(x);
function winProbability(elo, settings){
  if(!finite(elo)||!settings||!finite(settings.starting_rating)||!finite(settings.logistic_scale)||settings.logistic_scale<=0) return null;
  const probability=1/(1+Math.pow(10,-(elo-settings.starting_rating)/settings.logistic_scale));
  return Math.max(.01,Math.min(.99,probability));
}
function project(record, rating, settings, options={}){
  if(!record||![record.wins,record.losses].every(x=>Number.isInteger(x)&&x>=0)||record.wins+record.losses>82) return null;
  const baseline=winProbability(rating,settings); if(baseline===null) return null;
  const remaining=82-record.wins-record.losses;
  const modifier=options.modifier===undefined?0:Number(options.modifier);
  if(!Number.isFinite(modifier)||Math.abs(modifier)>100) return null;
  // The user-supplied modifier is a scenario parameter, not a fitted injury, schedule or player effect.
  const chance=Math.max(.01,Math.min(.99,1/(1+Math.pow(10,-(rating+modifier-settings.starting_rating)/settings.logistic_scale))));
  const n=Number.isInteger(options.runs)&&options.runs>=100&&options.runs<=20000?options.runs:4000;
  let seed=(Number.isInteger(options.seed)?options.seed:20261117)>>>0;
  const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
  const wins=[];
  for(let s=0;s<n;s++){let w=record.wins;for(let g=0;g<remaining;g++)if(rand()<chance)w++;wins.push(w)}
  wins.sort((a,b)=>a-b);
  const quantile=q=>wins[Math.max(0,Math.min(n-1,Math.floor(q*(n-1))))];
  return {played:record.wins+record.losses,remaining,observedWins:record.wins,observedLosses:record.losses,
    baselineProbability:baseline,scenarioProbability:chance,modifier,estimatedWins:record.wins+remaining*chance,
    p10:quantile(.1),p50:quantile(.5),p90:quantile(.9),runs:n,
    status:'neutral-opponent illustrative simulation; not an official record projection or schedule-based forecast'};
}
const api={project,winProbability};
if(typeof module!=='undefined'&&module.exports)module.exports=api;
root.AureumProjection=api;
})(typeof window!=='undefined'?window:globalThis);
