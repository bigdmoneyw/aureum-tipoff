/* A historical, source-cited mini sample, NEVER a live or trained prediction feed. */
(() => {
  'use strict';
  const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const allowed = ['https://www.basketball-reference.com/boxscores/?day=13&month=11&year=2026','https://www.nba.com/game/gsw-vs-sas-0022600040','https://www.nba.com/schedule'];
  const valid = d => d && d.schema_version === 1 && d.kind === 'historical_spot_check_not_model_training' &&
    d.verified_date === '2026-11-14' && d.results_date === '2026-11-13' &&
    d.results_source === allowed[0] && d.cross_check_source === allowed[1] && d.schedule_source === allowed[2] &&
    Array.isArray(d.completed_games) && d.completed_games.length === 9 &&
    Array.isArray(d.scheduled_games) && d.scheduled_games.length === 5 &&
    d.completed_games.every(g => /^[A-Z]{2,3}$/.test(g.home) && /^[A-Z]{2,3}$/.test(g.away) && g.home!==g.away &&
       Number.isInteger(g.home_score) && Number.isInteger(g.away_score) && g.home_score >= 0 && g.away_score >= 0 && g.home_score !== g.away_score) &&
    d.scheduled_games.every(g => /^[A-Z]{2,3}$/.test(g.home) && /^[A-Z]{2,3}$/.test(g.away) && g.home!==g.away &&
       /^2026-11-15T0[01]:[0-5][0-9]:00Z$/.test(g.tipoff_utc));
  document.addEventListener('DOMContentLoaded', async () => {
    const target=document.getElementById('verifiedSpotcheckBody');
    if (!target) return;
    try {
      const res=await fetch('editorial/verified-nba-sample.json',{cache:'no-store'});
      if (!res.ok) throw Error('Sample source unavailable');
      const d=await res.json();
      if (!valid(d)) throw Error('Sample source invalid');
      const last=new Date(Math.max(...d.scheduled_games.map(g=>Date.parse(g.tipoff_utc))));
      const scheduledStillFuture=Date.now()<last.getTime();
      const completed=d.completed_games.map(g => `<span style="display:inline-block;margin:5px 10px 5px 0">${esc(g.away)} ${g.away_score} · ${esc(g.home)} ${g.home_score}</span>`).join('');
      const scheduled=d.scheduled_games.map(g => `<span style="display:inline-block;margin:5px 10px 5px 0">${esc(g.away)} @ ${esc(g.home)} (${esc(new Date(g.tipoff_utc).toLocaleString(undefined,{timeZone:'America/New_York',hour:'numeric',minute:'2-digit'}))} ET)</span>`).join('');
      target.innerHTML=`<p><strong>Friday, November 13 · 9 verified final scores</strong></p><div>${completed}</div><p><strong>Saturday, November 14 · ${scheduledStillFuture?'5 scheduled at time of source check':'archived schedule snapshot, no longer current'}</strong></p><div>${scheduled}</div><p><a class="research-link" target="_blank" rel="noopener noreferrer" href="${allowed[0]}">Result source ↗</a> · <a class="research-link" target="_blank" rel="noopener noreferrer" href="${allowed[1]}">NBA game cross-check ↗</a> · <a class="research-link" target="_blank" rel="noopener noreferrer" href="${allowed[2]}">Official schedule ↗</a></p><p class="notice">Dated public-source spot check only. This snapshot is not automatically refreshed, does not establish franchise season records, and is not evidence that Aureum predicted any of these games.</p>`;
    } catch (_) {
      target.textContent='The historical source sample could not be validated; no results are displayed.';
    }
  });
})();
